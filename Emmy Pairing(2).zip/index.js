import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import bodyParser from 'body-parser';
import { EventEmitter } from 'events';
import pairRouter from './pair.js';
import 'dotenv/config';
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
global.__path = __dirname;

const app = express();
const PORT = process.env.PORT || 2532;

// Server statistics
const serverStats = {
  startTime: Date.now(),
  totalVisitors: 0,
  totalRequests: 0,
  successfulRequests: 0,
  failedRequests: 0,
  activeConnections: 0
};

// Increase event listeners limit
EventEmitter.defaultMaxListeners = 500;

// Middleware to track requests
app.use((req, res, next) => {
  serverStats.totalRequests++;
  
  // Track visitors (unique IPs - simplified)
  if (req.path === '/') {
    serverStats.totalVisitors++;
  }
  
  serverStats.activeConnections++;
  
  // Track response status
  const originalSend = res.send;
  res.send = function(data) {
    if (res.statusCode >= 200 && res.statusCode < 400) {
      serverStats.successfulRequests++;
    } else {
      serverStats.failedRequests++;
    }
    serverStats.activeConnections--;
    return originalSend.call(this, data);
  };
  
  next();
});

// API endpoint for stats
app.get('/api/stats', (req, res) => {
  const uptime = Date.now() - serverStats.startTime;
  const uptimeHours = Math.floor(uptime / (1000 * 60 * 60));
  const uptimeMinutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
  const uptimeSeconds = Math.floor((uptime % (1000 * 60)) / 1000);
  
  res.json({
    ...serverStats,
    uptime: {
      milliseconds: uptime,
      formatted: `${uptimeHours}h ${uptimeMinutes}m ${uptimeSeconds}s`
    }
  });
});

// Body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.use('/code', pairRouter);

// Serve main page
app.use('/', async (req, res, next) => {
  res.sendFile(join(__dirname, 'pair.html'));
});

app.listen(PORT, () => {
    console.log('INFO', `Server running on PORT:${PORT}`)
})

export { serverStats };