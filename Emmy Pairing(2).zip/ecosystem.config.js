module.exports = {
  apps: [{
    name: 'emmyx-pair',
    script: './index.js',
    instances: 1,
    exec_mode: 'fork',
    
    // Memory management
    max_memory_restart: '8G',
    
    // Auto-restart configuration
    autorestart: true,
    max_restarts: 10,
    min_uptime: '10s',
    
    // Logging
    error_file: './logs/error.log',
    out_file: './logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    merge_logs: true,
    
    // Environment variables
    env: {
      NODE_ENV: 'production',
      NODE_OPTIONS: '--max-old-space-size=8192'
    },
    
    // Restart delay
    restart_delay: 4000,
    
    // Watch and ignore
    watch: false,
    ignore_watch: ['node_modules', 'logs', 'database', 'uploads', 'bots'],
    
    // Kill timeout
    kill_timeout: 5000,
    
    // Exponential backoff restart delay
    exp_backoff_restart_delay: 100
  }]
};