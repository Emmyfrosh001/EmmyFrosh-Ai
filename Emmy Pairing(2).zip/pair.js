import "./logger.js";
import express from "express";
import fs from "fs";
import path from "path";
import pino from "pino";
import crypto from "crypto";
import {
  makeWASocket,
  useMultiFileAuthState,
  delay,
  makeCacheableSignalKeyStore,
  Browsers,
  DisconnectReason,
  fetchLatestBaileysVersion,
  jidDecode
} from "@whiskeysockets/baileys";
import AdmZip from "adm-zip";

const router = express.Router();
const sessionResults = new Map();

const API_PASSWORD = "passcode2026";
const BACKUP_DIR = "./backups";
const SESSION_PREFIX = "EmmyFrosh-Ai:~";

function ensureDir(dir) {
  try {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  } catch (e) {
    console.error(`[FS ERROR] Failed to ensure dir ${dir}:`, e.message);
  }
}

function removeFolder(folderPath) {
  try {
    if (fs.existsSync(folderPath)) {
      fs.rmSync(folderPath, { recursive: true, force: true });
      console.log(`[CLEANUP] Successfully removed folder: ${folderPath}`);
    }
  } catch (e) {
    console.error(`[CLEANUP ERROR] Failed to remove ${folderPath}:`, e.message);
  }
}

function removeFile(filePath) {
  try {
    if (fs.existsSync(filePath)) fs.rmSync(filePath, { force: true });
  } catch {}
}

function randomId32() {
  return crypto.randomBytes(16).toString("hex");
}

function zipSessionToBackup(sessionDir, id) {
  ensureDir(BACKUP_DIR);
  const zipPath = path.join(BACKUP_DIR, `${id}.zip`);
  const zip = new AdmZip();
  zip.addLocalFolder(sessionDir, "");
  zip.writeZip(zipPath);
  return zipPath;
}

function getAuthPassword(req) {
  const header = req.headers?.authorization || "";
  if (header.toLowerCase().startsWith("bearer ")) return header.slice(7).trim();
  return String(req.query?.password || "");
}

const decodeJid = (jid) => {
  try {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
    }
    return jid;
  } catch (e) {
    return jid;
  }
};

router.get("/restore", (req, res) => {
  const password = getAuthPassword(req);
  const id = String(req.query?.id || "").trim();

  if (!password || password !== API_PASSWORD) {
    return res.status(401).json({ success: false, error: "Unauthorized" });
  }

  if (!id || !/^[a-f0-9]{32}$/i.test(id)) {
    return res.status(400).json({ success: false, error: "Invalid id" });
  }

  const zipPath = path.join(BACKUP_DIR, `${id}.zip`);

  if (!fs.existsSync(zipPath)) {
    return res.status(404).json({ success: false, error: "Session ID expired. Pair or scan again." });
  }

  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", `attachment; filename="${id}.zip"`);
  fs.createReadStream(zipPath).pipe(res);
});

router.get("/get-session", (req, res) => {
  const number = req.query.number;
  const sessionId = sessionResults.get(number);
  if (sessionId) {
    res.json({ success: true, sessionId });
  } else {
    res.json({ success: false });
  }
});

router.get("/", async (req, res) => {
  const timestamp = Date.now();
  const sessionDir = `./session/${timestamp}`;
  const credsPath = path.join(sessionDir, "creds.json");
  const phoneNumber = req.query.number;
  const sanitizedNumber = phoneNumber ? phoneNumber.replace(/[^0-9]/g, "") : "Unknown";

  console.log(`[REQUEST] Incoming pairing request for: ${sanitizedNumber}`);

  ensureDir(sessionDir);
  console.log(`[FS] Created session directory: ${sessionDir}`);

  async function startAuthProcess() {
    try {
      console.log(`[AUTH] Initializing WASocket for ${sanitizedNumber}`);
      const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
      const { version } = await fetchLatestBaileysVersion();

      const ctx = makeWASocket({
        auth: {
          creds: state.creds,
          keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }))
        },
        logger: pino({ level: "fatal" }),
        printQRInTerminal: false,
        version,
        browser: Browsers.ubuntu("Edge")
      });

      if (!ctx.authState.creds.registered) {
        console.log(`[PAIRING] Requesting pairing code for ${sanitizedNumber}`);
        await delay(1500);
        setTimeout(async () => {
          try {
            const code = await ctx.requestPairingCode(sanitizedNumber);
            const formattedCode = code?.match(/.{1,4}/g)?.join("-");
            console.log(`[PAIRING] Code generated: ${formattedCode}`);
            if (!res.headersSent) res.send({ code: formattedCode });
          } catch (error) {
            console.error(`[PAIRING ERROR] Failed for ${sanitizedNumber}:`, error.message);
            if (!res.headersSent) res.status(500).send({ code: "ERROR" });
          }
        }, 3000);
      }

      ctx.ev.on("creds.update", () => {
        console.log(`[CREDS] Updating credentials for ${sanitizedNumber}`);
        saveCreds();
      });

      ctx.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        console.log(`[CONN] Status: ${connection} for ${sanitizedNumber}`);

if (connection === "open") {
  const userJid = decodeJid(ctx.user?.id || ctx.authState.creds.me?.id);
  console.log(`[CONN] Connection successful! JID: ${userJid}`);

  await delay(10000); 

  // ✅ Ensure it's actually registered
  if (!ctx.authState.creds.registered) {
    console.log(`[WAIT] Not fully registered yet, skipping...`);
    return;
  }

  try {
    const backupId = randomId32();

    console.log(`[BACKUP] Creating backup zip for ${sanitizedNumber}...`);
    const zipPath = zipSessionToBackup(sessionDir, backupId);

    const finalSessionId = `${SESSION_PREFIX}${backupId}`;

    if (userJid) {
      console.log(`[MSG] Sending Session ID to user...`);

      const sentMsg = await ctx.sendMessage(userJid, { text: finalSessionId });

      await ctx.sendMessage(
        userJid,
        {
          text:
            `🟢 Session verified successfully!\n\n` +
            `*TYPE:* BACKUP-ID\n` +
            `*STATUS:* Active and Working ✅\n` +
            `*RESTORE:* /restore?id=${backupId}`
        },
        { quoted: sentMsg }
      );

      sessionResults.set(sanitizedNumber, finalSessionId);
      setTimeout(() => sessionResults.delete(sanitizedNumber), 300000);

      setTimeout(() => {
        removeFile(zipPath);
        console.log(`[EXPIRE] Backup expired: ${backupId}`);
      }, 300000);
    }

    await delay(4000);

    try { ctx.ws.close(); } catch {}
    try { ctx.end(); } catch {}
    removeFolder(sessionDir);

  } catch (err) {
    console.error(`[FINAL ERROR] ${sanitizedNumber}:`, err.message);
  }
} else if (connection === "close") {
          const reason = lastDisconnect?.error?.output?.statusCode;
          console.log(`[CONN] Closed for ${sanitizedNumber}. Reason code: ${reason}`);

          if (
            [DisconnectReason.connectionLost, DisconnectReason.connectionClosed, DisconnectReason.restartRequired].includes(
              reason
            )
          ) {
            console.log(`[RECONN] Attempting to reconnect ${sanitizedNumber}...`);
            startAuthProcess();
          } else {
            console.log(`[CONN] Permanent disconnection. Cleaning up ${sanitizedNumber}`);
            removeFolder(sessionDir);
          }
        }
      });
    } catch (err) {
      console.error(`[FATAL ERROR] ${sanitizedNumber}:`, err.message);
      removeFolder(sessionDir);
      if (!res.headersSent) res.status(503).send({ code: "UNAVAILABLE" });
    }
  }

  await startAuthProcess();
});

export default router;