
module.exports = {
  command: ['antilink', 'al'],
  alias: ['linkguard', 'linkprotect'],
  category: 'group',
  description: 'Protect group from link spam (admin only)',
  group: true,
  admin: true,
  async execute(m, { ednut, isGroup, isAdmins, isBotAdmins, prefix, command, text, reply, botNumber }) {
    
    const modes = {
      '1': 'delete only - Messages with links will be deleted',
      '2': 'kick - Users will be kicked immediately when sending links',
      '3': 'warn (3x) then delete',
      '4': 'warn (3x) then kick',
      'off': 'disabled - No link protection'
    };
    
    // Show available modes
    if (text.toLowerCase() === 'modes' || text.toLowerCase() === 'help') {
      let modeList = '📋 *ANTILINK MODES*\n\n';
      for (const [key, value] of Object.entries(modes)) {
        modeList += `▢ *${key}*: ${value}\n\n`;
      }
      modeList += `\n_Usage: ${prefix + command} [mode]_\n`;
      modeList += `_Example: ${prefix + command} 1_`;
      await reply(modeList);
      return;
    }
    
    // Enable/disable antilink with specific mode
    if (text.toLowerCase() === '1') {
      if (!global.db.groups) global.db.groups = {};
      if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
      
      global.db.groups[m.chat].antilink = true;
      global.db.groups[m.chat].antilink2 = false;
      global.db.groups[m.chat].antilink3 = false;
      global.db.groups[m.chat].antilink4 = false;
      global.db.groups[m.chat].antilinkMode = 'delete';
      global.db.groups[m.chat].antilinkWarnings = global.db.groups[m.chat].antilinkWarnings || {};
      
      await reply(`✅ *Antilink activated!*\n\n*Mode:* Delete only\n\nAny link messages will be deleted.\n\n_Use ${prefix + command} off to disable._`);
      
    } else if (text.toLowerCase() === '2') {
      if (!global.db.groups) global.db.groups = {};
      if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
      
      global.db.groups[m.chat].antilink = false;
      global.db.groups[m.chat].antilink2 = true;
      global.db.groups[m.chat].antilink3 = false;
      global.db.groups[m.chat].antilink4 = false;
      global.db.groups[m.chat].antilinkMode = 'kick';
      global.db.groups[m.chat].antilinkWarnings = global.db.groups[m.chat].antilinkWarnings || {};
      
      await reply(`✅ *Antilink activated!*\n\n*Mode:* Kick immediately\n\nUsers sending links will be kicked from the group.\n\n_Use ${prefix + command} off to disable._`);
      
    } else if (text.toLowerCase() === '3') {
      if (!global.db.groups) global.db.groups = {};
      if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
      
      global.db.groups[m.chat].antilink = false;
      global.db.groups[m.chat].antilink2 = false;
      global.db.groups[m.chat].antilink3 = true;
      global.db.groups[m.chat].antilink4 = false;
      global.db.groups[m.chat].antilinkMode = 'warn_delete';
      global.db.groups[m.chat].antilinkWarnings = global.db.groups[m.chat].antilinkWarnings || {};
      global.db.groups[m.chat].maxWarnings = 3;
      
      await reply(`✅ *Antilink activated!*\n\n*Mode:* Warn then Delete (3 warnings)\n\nUsers will be warned for sending links, and after 3 warnings, messages will be deleted automatically.\n\n_Use ${prefix + command} off to disable._`);
      
    } else if (text.toLowerCase() === '4') {
      if (!global.db.groups) global.db.groups = {};
      if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
      
      global.db.groups[m.chat].antilink = false;
      global.db.groups[m.chat].antilink2 = false;
      global.db.groups[m.chat].antilink3 = false;
      global.db.groups[m.chat].antilink4 = true;
      global.db.groups[m.chat].antilinkMode = 'warn_kick';
      global.db.groups[m.chat].antilinkWarnings = global.db.groups[m.chat].antilinkWarnings || {};
      global.db.groups[m.chat].maxWarnings = 3;
      
      await reply(`✅ *Antilink activated!*\n\n*Mode:* Warn then Kick (3 warnings)\n\nUsers will be warned for sending links, and kicked after 3 warnings.\n\n_Use ${prefix + command} off to disable._`);
      
    } else if (text.toLowerCase() === 'off' || text.toLowerCase() === 'disable' || text.toLowerCase() === '0') {
      if (!global.db.groups) global.db.groups = {};
      if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
      
      global.db.groups[m.chat].antilink = false;
      global.db.groups[m.chat].antilink2 = false;
      global.db.groups[m.chat].antilink3 = false;
      global.db.groups[m.chat].antilink4 = false;
      global.db.groups[m.chat].antilinkMode = 'off';
      
      await reply(`❌ *Antilink deactivated!*\n\nNo link protection is active in this group.`);
      
    } else if (text.toLowerCase() === 'status') {
      const mode = global.db.groups?.[m.chat]?.antilinkMode || 'off';
      let statusText = '';
      let warningCount = 0;
      
      if (mode === 'delete') statusText = 'Delete only (Mode 1)';
      else if (mode === 'kick') statusText = 'Kick immediately (Mode 2)';
      else if (mode === 'warn_delete') statusText = 'Warn then Delete (Mode 3)';
      else if (mode === 'warn_kick') statusText = 'Warn then Kick (Mode 4)';
      else statusText = 'Disabled';
      
      // Count total warnings if in warn mode
      if (mode === 'warn_delete' || mode === 'warn_kick') {
        const warnings = global.db.groups[m.chat].antilinkWarnings || {};
        warningCount = Object.keys(warnings).length;
      }
      
      await reply(`📋 *Antilink Status*\n\n*Mode:* ${statusText}\n*Active:* ${mode !== 'off' ? '✅ Yes' : '❌ No'}\n${warningCount > 0 ? `*Active Warnings:* ${warningCount} users\n` : ''}\nTo change mode:\n${prefix + command} [1/2/3/4/off]\n\nTo see all modes: ${prefix + command} modes`);
      
    } else if (text.toLowerCase() === 'resetwarnings' || text.toLowerCase() === 'reset') {
      if (!global.db.groups) global.db.groups = {};
      if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
      
      // Reset specific user or all
      const target = text.split(' ')[1];
      if (target && target.startsWith('@')) {
        const targetJid = target.replace('@', '') + '@s.whatsapp.net';
        if (global.db.groups[m.chat].antilinkWarnings[targetJid]) {
          delete global.db.groups[m.chat].antilinkWarnings[targetJid];
          await reply(`✅ *Warnings reset for ${target}*`);
        } else {
          await reply(`ℹ️ No warnings found for ${target}`);
        }
      } else {
        global.db.groups[m.chat].antilinkWarnings = {};
        await reply(`✅ *All warnings reset!*\n\nAll antilink warnings for this group have been cleared.`);
      }
      
    } else if (text.toLowerCase() === 'setwarnings') {
      const maxWarnings = parseInt(text.split(' ')[1]);
      if (maxWarnings && maxWarnings >= 1 && maxWarnings <= 10) {
        if (!global.db.groups) global.db.groups = {};
        if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
        global.db.groups[m.chat].maxWarnings = maxWarnings;
        await reply(`✅ *Max warnings set to ${maxWarnings}*\n\nUsers will be punished after ${maxWarnings} warnings.`);
      } else {
        await reply(`❌ Invalid number!\n\nUsage: ${prefix + command} setwarnings [1-10]\nCurrent: ${global.db.groups?.[m.chat]?.maxWarnings || 3}`);
      }
      
    } else {
      const mode = global.db.groups?.[m.chat]?.antilinkMode || 'off';
      const maxWarnings = global.db.groups?.[m.chat]?.maxWarnings || 3;
      await reply(`📋 *Current Antilink Settings*\n\n*Mode:* ${mode !== 'off' ? `Mode ${mode === 'delete' ? '1' : mode === 'kick' ? '2' : mode === 'warn_delete' ? '3' : '4'}` : 'Off'}\n*Max Warnings:* ${maxWarnings}\n\nAvailable commands:\n- ${prefix + command} 1 - Delete only\n- ${prefix + command} 2 - Kick immediately\n- ${prefix + command} 3 - Warn then Delete\n- ${prefix + command} 4 - Warn then Kick\n- ${prefix + command} off - Disable\n- ${prefix + command} modes - Show all modes\n- ${prefix + command} status - Show current status\n- ${prefix + command} resetwarnings - Reset all warnings\n- ${prefix + command} resetwarnings @user - Reset warnings for specific user\n- ${prefix + command} setwarnings [1-10] - Set max warnings before punishment`);
    }
  }
};