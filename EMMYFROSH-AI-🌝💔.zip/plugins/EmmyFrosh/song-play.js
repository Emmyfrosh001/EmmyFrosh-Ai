const yts = require("youtube-yts");
const axios = require("axios");

module.exports = [
  {
    command: ["play"],
    alias: ["ytplay", "song", "music"],
    description: "Search and play a song from YouTube as audio",
    category: "Downloader",
    filename: __filename,
    async execute(m, { ednut, text, reply }) {
      try {
        if (!text) return reply("❌ Please provide a song name to search.");

        // 🔎 Search YouTube
        const search = await yts(text);
        const result = search.all?.[0];
        if (!result) return reply("❌ No video found.");

        const videoUrl = result.url;
        const title = result.title || text;

        // 🌐 CypherX API (audio)
        const apiUrl = `https://media.cypherxbot.space/download/youtube/audio?url=${encodeURIComponent(videoUrl)}`;
        const { data } = await axios.get(apiUrl);

        if (!data.status || !data.result.download_url) {
          return reply("❌ Failed to fetch audio.");
        }

        // ✅ Send audio (single response)
        await ednut.sendMessage(
          m.chat,
          {
            audio: { url: data.result.download_url },
            mimetype: "audio/mpeg",
            fileName: `${data.tittle || title}.mp3`,
            ptt: false,
            contextInfo: {
              externalAdReply: {
                title: data.tittle || title,
                body: "EmmyFrosh-AI",
                thumbnailUrl: data.thumbnail,
                mediaType: 1,
                renderLargerThumbnail: true,
                showAdAttribution: false
              }
            }
          },
          { quoted: m }
        );

      } catch (err) {
        await reply(`⚠️ Error: ${err.message || err}`);
      }
    },
  },
];