const axios = require("axios");

const session = new Map();

module.exports = {
  command: ["livescore"],
  alias: ["live", "fixtures", "nextmatch"],
  category: "Sport",
  description: "Live scores with REAL yellow/red cards (events API)",

  execute: async (m, { ednut, reply, args }) => {
    try {

      const filter = (args[0] || "").toLowerCase();
      const user = m.sender;

      // ================= MENU =================
      if (!filter) {
        session.set(user, true);

        return reply(
`⚽ SELECT LIVE LEAGUE:

.live epl
.live ucl
.live laliga
.live seriea
.live bundesliga
.live ligue1
.live eredivisie
.live mls
.live championship
.live brazil
.live argentina
.live all`
        );
      }

      if (!session.get(user)) {
        return reply("⚠️ Type .live first to open menu.");
      }

      // ================= LEAGUES =================
      const leagueMap = {
        epl: 39,
        ucl: 2,
        laliga: 140,
        seriea: 135,
        bundesliga: 78,
        ligue1: 61,
        eredivisie: 88,
        mls: 253,
        championship: 40,
        brazil: 71,
        argentina: 128,
        all: null
      };

      const headers = {
        "x-apisports-key": "a25d56a85c315a15e1da7faa08bcf4a5"
      };

      // ================= GLOBAL LIVE =================
      if (filter === "all") {

        const { data } = await axios.get(
          `https://v3.football.api-sports.io/fixtures?live=all`,
          { headers }
        );

        const matches = data?.response || [];

        if (!matches.length) {
          return reply("🔴 No live matches currently.");
        }

        let msg = `🌍 ⚽ GLOBAL LIVE SCORES\n━━━━━━━━━━━━━━\n\n`;

        for (let game of matches) {

          const fixtureId = game?.fixture?.id;

          const home = game?.teams?.home?.name || "Unknown";
          const away = game?.teams?.away?.name || "Unknown";

          const hg = game?.goals?.home ?? 0;
          const ag = game?.goals?.away ?? 0;

          let yellowHome = 0, yellowAway = 0;
          let redHome = 0, redAway = 0;

          try {
            const ev = await axios.get(
              `https://v3.football.api-sports.io/fixtures/events?fixture=${fixtureId}`,
              { headers }
            );

            const events = ev.data?.response || [];

            for (let e of events) {
              const teamName = e?.team?.name;
              const type = e?.type;

              if (type === "Card") {
                const detail = e?.detail;

                if (detail === "Yellow Card") {
                  if (teamName === home) yellowHome++;
                  if (teamName === away) yellowAway++;
                }

                if (detail === "Red Card") {
                  if (teamName === home) redHome++;
                  if (teamName === away) redAway++;
                }
              }
            }

          } catch (err) {}

          const status = game?.fixture?.status?.short;
          const min = game?.fixture?.status?.elapsed || "";

          let getStatus = (s, min) => {
            if (s === "1H") return `🔴 1ST HALF ${min}'`;
            if (s === "2H") return `🔴 2ND HALF ${min}'`;
            if (s === "HT") return "⏸ HALF TIME";
            if (s === "FT") return "✅ FULL TIME";
            if (s === "ET") return `🔥 EXTRA TIME ${min}'`;
            return `⚽ ${s}`;
          };

          msg += `🌍 ${home} vs ${away}\n`;
          msg += `📊 ${hg} - ${ag}\n`;
          msg += `🟨 ${yellowHome} - ${yellowAway}\n`;
          msg += `🟥 ${redHome} - ${redAway}\n`;
          msg += `⏱ ${getStatus(status, min)}\n`;
          msg += `━━━━━━━━━━━━━━\n\n`;
        }

        return ednut.sendMessage(m.chat, { text: msg }, { quoted: m });
      }

      // ================= SINGLE LEAGUE =================
      const leagueId = leagueMap[filter];

      if (!leagueId) {
        return reply("❌ Invalid league.\nType .live to see menu.");
      }

      const { data } = await axios.get(
        `https://v3.football.api-sports.io/fixtures?live=all&league=${leagueId}&season=2026`,
        { headers }
      );

      const matches = data?.response || [];

      if (!matches.length) {
        return reply("🔴 No live matches found.");
      }

      let msg = `⚽ LIVE SCORES (${filter.toUpperCase()})\n━━━━━━━━━━━━━━\n\n`;

      for (let game of matches) {

        const fixtureId = game?.fixture?.id;

        const home = game?.teams?.home?.name;
        const away = game?.teams?.away?.name;

        const hg = game?.goals?.home ?? 0;
        const ag = game?.goals?.away ?? 0;

        let yellowHome = 0, yellowAway = 0;
        let redHome = 0, redAway = 0;

        try {
          const ev = await axios.get(
            `https://v3.football.api-sports.io/fixtures/events?fixture=${fixtureId}`,
            { headers }
          );

          const events = ev.data?.response || [];

          for (let e of events) {
            const teamName = e?.team?.name;
            const type = e?.type;

            if (type === "Card") {
              const detail = e?.detail;

              if (detail === "Yellow Card") {
                if (teamName === home) yellowHome++;
                if (teamName === away) yellowAway++;
              }

              if (detail === "Red Card") {
                if (teamName === home) redHome++;
                if (teamName === away) redAway++;
              }
            }
          }

        } catch (err) {}

        const status = game?.fixture?.status?.short;
        const min = game?.fixture?.status?.elapsed || "";

        let getStatus = (s, min) => {
          if (s === "1H") return `🔴 1ST HALF ${min}'`;
          if (s === "2H") return `🔴 2ND HALF ${min}'`;
          if (s === "HT") return "⏸ HALF TIME";
          if (s === "FT") return "✅ FULL TIME";
          if (s === "ET") return `🔥 EXTRA TIME ${min}'`;
          return `⚽ ${s}`;
        };

        msg += `⚽ ${home} vs ${away}\n`;
        msg += `📊 ${hg} - ${ag}\n`;
        msg += `🟨 ${yellowHome} - ${yellowAway}\n`;
        msg += `🟥 ${redHome} - ${redAway}\n`;
        msg += `⏱ ${getStatus(status, min)}\n`;
        msg += `━━━━━━━━━━━━━━\n\n`;
      }

      await ednut.sendMessage(m.chat, { text: msg }, { quoted: m });

    } catch (e) {
      console.log(e);
      reply("❌ Failed to fetch live matches.");
    }
  }
};