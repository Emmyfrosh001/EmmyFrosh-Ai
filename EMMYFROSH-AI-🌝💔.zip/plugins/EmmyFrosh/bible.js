const axios = require("axios");

module.exports = [
  {
    command: ["bible"],
    description: "KJV Bible verse",
    category: "Info",

    async execute(m, { ednut, from, text, reply }) {
      try {
        const chatId = from || m.chat || m.key?.remoteJid;

        if (!text) {
          return reply(
            "📖 Example:\n.bible John 3:16\n.bible Genesis 1:1-5"
          );
        }

        await ednut.sendMessage(chatId, {
          text: "📖 _Fetching KJV Bible..._"
        });

        // 📚 KJV BIBLE API
        const url = `https://bible-api.com/${encodeURIComponent(text)}?translation=kjv`;

        const res = await axios.get(url, { timeout: 30000 });

        const data = res.data;

        if (!data || !data.verses) {
          return reply("❌ Verse not found in KJV Bible.");
        }

        // 📖 Format verses nicely
        let versesText = data.verses
          .map(v => `${v.verse}. ${v.text.trim()}`)
          .join("\n");

        const output =
          `📖 *HOLY BIBLE (KJV)*\n` +
          `════════════════════\n\n` +
          `📌 ${data.reference}\n\n` +
          `${versesText}\n\n` +
          `════════════════════\n🙏 KING JAMES VERSION`;

        await ednut.sendMessage(chatId, { text: output });

      } catch (err) {
        console.log("KJV BIBLE ERROR:", err.message);

        reply("❌ Failed to fetch KJV Bible. Try again later.");
      }
    }
  }
];