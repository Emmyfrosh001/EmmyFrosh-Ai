const os = require("os");
const moment = require("moment-timezone");
const { sizeFormatter } = require("human-readable");
const fs = require("fs");
const path = require("path");

// ================= MENU STORAGE =================
const menuFile = path.join(__dirname, "menu.json");

function loadMenu() {
  try {
    if (!fs.existsSync(menuFile)) {
      fs.writeFileSync(menuFile, JSON.stringify({ menuImage: null }, null, 2));
    }
    return JSON.parse(fs.readFileSync(menuFile));
  } catch (e) {
    return { menuImage: null };
  }
}

function saveMenu(data) {
  fs.writeFileSync(menuFile, JSON.stringify(data, null, 2));
}

// ================= STYLE =================
function smallCaps(text) {
  const map = {
    a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ғ', g: 'ɢ',
    h: 'ʜ', i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ',
    o: 'ᴏ', p: 'ᴘ', q: 'ǫ', r: 'ʀ', s: 's', t: 'ᴛ', u: 'ᴜ',
    v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ'
  };
  return text.toLowerCase().split("").map(c => map[c] || c).join("");
}

// ================= UTILS =================
const welDate = moment.tz(global.timezone).format("DD/MM/YYYY");

const formatp = sizeFormatter({
  std: "JEDEC",
  decimalPlaces: 2,
  render: (l, s) => `${l} ${s}B`,
});

const run = (s) => {
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = Math.floor(s % 60);
  return [d && `${d}d`, h && `${h}h`, m && `${m}m`, sec && `${sec}s`]
    .filter(Boolean)
    .join(" ");
};

const getTime = () =>
  moment.tz(global.timezone).format("HH:mm:ss");

// ================= EXPORT =================
module.exports = [

  // ================= MENU COMMAND =================
  {
    command: ["menu", "allmenu"],
    description: "Show bot menu",

    execute: async (m, { ednut, commands }) => {

      const data = loadMenu();

      const disabledCommands = Array.isArray(global.db.disabled)
        ? global.db.disabled.filter(Boolean).map(v => v.toLowerCase())
        : [];

      let totalEnabledCommands = 0;

      const categories = {
        EnvManager: [], Info: [], Fun: [], Ai: [], Group: [], Owner: [],
        Other: [], Logo: [], Search: [], Converter: [], Maker: [], Game: [],
        Tool: [], Downloader: [], Sport: [], Wa: [], External: [], Nsfw: [],
        Settings: [], Privacy: []
      };

      commands.forEach(cmd => {
        const category = cmd.category || "Info";
        const cmds = Array.isArray(cmd.command) ? cmd.command : [cmd.command];
        const isDisabled = cmds.some(c => c && disabledCommands.includes(c.toLowerCase()));

        if (categories[category] && !isDisabled) {
          cmds.filter(Boolean).forEach(c => categories[category].push(c));
          totalEnabledCommands += cmds.filter(Boolean).length;
        }
      });

      const userName = m.pushName || "User";
      const memoryUsed = formatp(os.totalmem() - os.freemem());
      const uptime = run(process.uptime());
      const currentTime = getTime();

      let menu = `┏━━{ *${smallCaps(global.botname)}* }━━━
⚛ 👤 ${smallCaps("User")}: ${userName}
⚛ 🟢 ${smallCaps("Ping")}: ${Date.now() - m.messageTimestamp * 1000} ms
⚛ ⏰ ${smallCaps("Time")}: ${currentTime}
⚛ 📅 ${smallCaps("Date")}: ${welDate}
⚛ ⚙️ ${smallCaps("Commands")}: ${totalEnabledCommands}
⚛ 🔶 ${smallCaps("Memory")}: ${memoryUsed}
⚛ ❤️ ${smallCaps("Uptime")}: ${uptime}
┗━━━━━━━━━━━━━━━\n\n`;

      Object.keys(categories).forEach(category => {
        if (categories[category].length > 0) {
          menu += `╭─❏〘 ${smallCaps(category)} 〙━━━━❒\n`;

          [...new Set(categories[category])]
            .sort()
            .forEach(cmd => {
              menu += `│ ${global.prefix}${smallCaps(cmd)}\n`;
            });

          menu += `╰───────────╯\n\n`;
        }
      });

      let msg = { text: menu };

      if (data.menuImage) {
        msg = {
          image: { url: data.menuImage },
          caption: menu
        };
      }

      return await ednut.sendMessage(m.chat, msg, { quoted: m });
    }
  },

  // ================= SET MENU IMAGE =================
  {
    command: ["setmenuimg"],
    description: "Set menu image (URL only)",

    execute: async (m, { text, reply }) => {
      if (!text) return reply("❌ Send image URL");
      if (!text.startsWith("http")) return reply("❌ Only image URL allowed");

      const data = loadMenu();
      data.menuImage = text;
      saveMenu(data);

      return reply("✅ Menu image saved successfully");
    }
  },

  // ================= DELETE MENU IMAGE =================
  {
    command: ["delmenuimg"],
    description: "Remove menu image",

    execute: async (m, { reply }) => {
      const data = loadMenu();
      data.menuImage = null;
      saveMenu(data);

      return reply("🗑️ Menu image removed successfully");
    }
  }

];