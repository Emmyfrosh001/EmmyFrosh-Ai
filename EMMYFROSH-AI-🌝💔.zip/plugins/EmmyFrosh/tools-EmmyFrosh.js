const axios = require("axios");
const yts = require("yt-search");

module.exports = [
  {
    command: ["readmore"],
    description: "Hide text using read more",
    category: "Tool",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, text }) => {
      const more = String.fromCharCode(8206);
      const readmore = more.repeat(4001);
      let [l = '', r = ''] = text.split('|');
      await ednut.sendMessage(m.chat, { text: l + readmore + r }, { quoted: m });
    }
  },

  {
    command: ["lyrics"],
    alias: ["ly"],
    description: "Get song lyrics (smart search)",
    category: "Tool",

    async execute(m, { text, reply }) {
      try {
        if (!text) {
          return reply("❌ Example:\n#lyrics calm down by rema");
        }

        let input = text.toLowerCase();

        // 🧠 CLEAN INPUT
        input = input
          .replace("lyrics", "")
          .replace("by", "-")
          .trim();

        let artist = "";
        let title = "";

        // 🔥 CASE 1: artist - song
        if (input.includes("-")) {
          const parts = input.split("-");
          artist = parts[0].trim();
          title = parts.slice(1).join("-").trim();
        }

        // 🔥 CASE 2: auto detect via yt search
        else {
          const search = await yts(input);

          if (!search.videos.length) {
            return reply("❌ Song not found.");
          }

          const vid = search.videos[0];

          if (vid.title.includes("-")) {
            const parts = vid.title.split("-");
            artist = parts[0].trim();
            title = parts.slice(1).join("-").trim();
          } else {
            artist = "Unknown";
            title = vid.title;
          }
        }

        // 📥 FETCH LYRICS
        const apiUrl =
          `https://api.lyrics.ovh/v1/${encodeURIComponent(artist)}/${encodeURIComponent(title)}`;

        const { data } = await axios.get(apiUrl);

        console.log("LYRICS DATA:", data);

        if (!data || !data.lyrics) {
          return reply("❌ Lyrics not found.");
        }

        const lyrics =
          data.lyrics.length > 4000
            ? data.lyrics.slice(0, 4000) + "\n\n..."
            : data.lyrics;

        await reply(
          `🎵 *${title}*\n` +
          `👤 Artist: *${artist}*\n\n` +
          `${lyrics}`
        );

      } catch (err) {
        console.log(err);
        reply("❌ Failed to fetch lyrics.");
      }
    }
  },

  {
    command: ["trackip"],
    description: "Track IP address information",
    category: "Tool",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, text, fetch }) => {
      if (!text) return m.reply("Example: 112.90.150.204");

      try {
        let res = await fetch(`https://ipwho.is/${text}`).then(r => r.json());
        if (!res.success) throw new Error(`IP ${text} not found!`);

        const info =
`IP: ${res.ip}
Country: ${res.country}
Region: ${res.region}
City: ${res.city}
Latitude: ${res.latitude}
Longitude: ${res.longitude}
ISP: ${res.connection?.isp}
Org: ${res.connection?.org}
Timezone: ${res.timezone?.id} (${res.timezone?.current_time})`;

        await ednut.sendMessage(m.chat, {
          location: {
            degreesLatitude: res.latitude,
            degreesLongitude: res.longitude
          }
        }, { ephemeralExpiration: 604800 });

        await new Promise(resolve => setTimeout(resolve, 2000));
        m.reply(info);

      } catch (err) {
        console.log(err);
        m.reply(`Error: Unable to retrieve data for IP ${text}`);
      }
    }
  },

  {
    command: ["tts"],
    alias: ["say", "gtts"],
    description: "Convert text to speech",
    category: "Converter",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, args, q, googleTTS }) => {
      let text = args.length > 1 ? args.slice(1).join(" ") : q;
      if (!text) return m.reply("Missing text.");

      let voiceLanguage = 'en-US';
      let speed = false;
      const style = args[0]?.toLowerCase();

      switch (style) {
        case "female": voiceLanguage = "en-GB"; break;
        case "deep": voiceLanguage = "en-IN"; break;
        case "slow": speed = true; break;
        case "ng": voiceLanguage = "en-NG"; break;
        case "au": voiceLanguage = "en-AU"; break;
      }

      if (text.length > 200) return m.reply("Text must be under 200 characters.");

      try {
        const url = googleTTS.getAudioUrl(text, {
          lang: voiceLanguage,
          slow: speed,
          host: 'https://translate.google.com'
        });

        await ednut.sendMessage(
          m.chat,
          { audio: { url }, mimetype: 'audio/mpeg', ptt: true },
          { quoted: m }
        );

      } catch (err) {
        console.log(err);
        m.reply('Error occurred while converting text to speech.');
      }
    }
  },

  {
    command: ["device"],
    alias: ["getdevice", "phone"],
    description: "Detect device from quoted message",
    category: "Tool",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, getDevice }) => {
      if (!m.quoted) return m.reply("Reply to a message");

      try {
        const device = await getDevice(m.quoted.id);

        await ednut.sendMessage(m.chat, {
          text: `@${m.quoted.sender.split('@')[0]} is using ${device}`,
          contextInfo: {
            mentionedJid: [m.quoted.sender]
          }
        }, { quoted: m });

      } catch (err) {
        console.log(err);
        m.reply('Error occurred while fetching device info.');
      }
    }
  }
];