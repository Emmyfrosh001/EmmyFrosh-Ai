// plugins/EmmyFrosh/antidelete.js

const fs = require('fs');
const path = require('path');
const CONFIG_PATH = path.join(__dirname, '../data/antidelete.json');

// Load config
function loadAntideleteConfig() {
    try {
        if (!fs.existsSync(CONFIG_PATH)) return { enabled: true, forwardToOwner: true };
        return JSON.parse(fs.readFileSync(CONFIG_PATH));
    } catch {
        return { enabled: true, forwardToOwner: true };
    }
}

// Save config
function saveAntideleteConfig(config) {
    try {
        const dir = path.dirname(CONFIG_PATH);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    } catch (err) {
        console.error('Config save error:', err);
    }
}

module.exports = {
  command: ['antidelete', 'ad'],
  alias: ['viewdelete', 'seendelete'],
  category: 'group',
  description: 'View deleted messages in group (admin only)',
  group: true,
  admin: true,
  async execute(m, { ednut, isGroup, isAdmins, isBotAdmins, prefix, command, text, reply, botNumber, isOwner }) {
    
    const config = loadAntideleteConfig();
    
    // Toggle antidelete feature
    if (text.toLowerCase() === 'on' || text.toLowerCase() === 'enable') {
      config.enabled = true;
      saveAntideleteConfig(config);
      await reply(`✅ *Antidelete activated!*\n\nI will now capture and report deleted messages.\n\n_Use ${prefix + command} off to disable._\n_Use ${prefix + command} forward on to forward to owner._`);
      
    } else if (text.toLowerCase() === 'off' || text.toLowerCase() === 'disable') {
      config.enabled = false;
      saveAntideleteConfig(config);
      await reply(`❌ *Antidelete deactivated!*\n\nI will no longer capture deleted messages.`);
      
    } else if (text.toLowerCase() === 'forward on' || text.toLowerCase() === 'forward enable') {
      config.forwardToOwner = true;
      saveAntideleteConfig(config);
      await reply(`✅ *Forward to owner activated!*\n\nDeleted messages will be forwarded to the bot owner.\n\n_Use ${prefix + command} forward off to disable._`);
      
    } else if (text.toLowerCase() === 'forward off' || text.toLowerCase() === 'forward disable') {
      config.forwardToOwner = false;
      saveAntideleteConfig(config);
      await reply(`❌ *Forward to owner deactivated!*\n\nDeleted messages will no longer be forwarded to owner.`);
      
    } else if (text.toLowerCase() === 'status' || text === '') {
      await reply(`📋 *Antidelete Status*\n\nStatus: ${config.enabled ? '✅ Active' : '❌ Inactive'}\nForward to Owner: ${config.forwardToOwner ? '✅ Yes' : '❌ No'}\n\nCommands:\n- ${prefix + command} on - Activate antidelete\n- ${prefix + command} off - Deactivate antidelete\n- ${prefix + command} forward on - Forward deleted to owner\n- ${prefix + command} forward off - Stop forwarding to owner\n- ${prefix + command} status - Check current status`);
      
    } else {
      await reply(`❌ Invalid option!\n\nUsage:\n- ${prefix + command} on - Activate antidelete\n- ${prefix + command} off - Deactivate antidelete\n- ${prefix + command} forward on/off - Toggle forwarding to owner\n- ${prefix + command} status - Check current status`);
    }
  }
};