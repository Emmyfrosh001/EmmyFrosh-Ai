const axios = require("axios");

async function ssweb(
  url,
  { width = 1280, height = 720, full_page = false, device_scale = 1 } = {}
) {
  try {
    if (!url.startsWith("http")) throw new Error("Invalid url");
    if (
      isNaN(width) ||
      isNaN(height) ||
      isNaN(device_scale)
    ) throw new Error("Width, height, and scale must be numbers");

    if (typeof full_page !== "boolean")
      throw new Error("Full page must be boolean");

    const { data } = await axios.post(
      "https://gcp.imagy.app/screenshot/createscreenshot",
      {
        url: url,
        browserWidth: parseInt(width),
        browserHeight: parseInt(height),
        fullPage: full_page,
        deviceScaleFactor: parseInt(device_scale),
        format: "png",
      },
      {
        headers: {
          "content-type": "application/json",
          referer: "https://imagy.app/full-page-screenshot-taker/",
          "user-agent":
            "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome Mobile Safari",
        },
      }
    );

    return data.fileUrl;
  } catch (e) {
    throw new Error(e.message);
  }
}

module.exports = [
  {
    command: ["ssweb"],
    alias: ["screenshot", "webss"],
    description: "Take website screenshot (reply supported)",
    category: "Converter",

    execute: async (m, { ednut, reply, args }) => {
      try {

        // =========================
        // MUST REPLY OR ARG
        // =========================
        const text =
          args.join(" ") ||
          m.quoted?.text;

        if (!text) {
          return reply("📸 Reply or use:\n.ssweb https://google.com");
        }

        const urlMatch = text.match(/https?:\/\/[^\s]+/);

        if (!urlMatch) {
          return reply("❌ No valid URL found.");
        }

        const url = urlMatch[0];

        reply("⏳ Taking screenshot...");

        const img = await ssweb(url);

        await ednut.sendMessage(
          m.chat,
          {
            image: { url: img },
            caption: "✅ Screenshot taken successfully"
          },
          { quoted: m }
        );

      } catch (e) {
        reply(`❌ Error: ${e.message}`);
      }
    }
  }
];