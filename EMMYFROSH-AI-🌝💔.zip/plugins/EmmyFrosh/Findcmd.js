const fs = require("fs");
const path = require("path");

module.exports = [
  {
    command: ["findcmd"],
    alias: ["file", "cmdfind", "ff"],
    description: "Find command file by name",
    category: "Tool",

    async execute(m, { text, reply }) {
      try {
        if (!text) {
          return reply("❌ Example:\n#find play");
        }

        const search = text.toLowerCase().trim();

        // 📁 COMMAND FOLDER
        const baseFolder = path.join(__dirname);

        let results = [];

        function scan(dir) {
          const files = fs.readdirSync(dir);

          for (let file of files) {
            const fullPath = path.join(dir, file);
            const stat = fs.statSync(fullPath);

            if (stat.isDirectory()) {
              scan(fullPath);
            } else if (file.endsWith(".js")) {

              const fileName = path.parse(file).name.toLowerCase();
              const content = fs.readFileSync(fullPath, "utf8").toLowerCase();

              // 🔍 MATCH RULE (filename OR inside file)
              if (
                fileName.includes(search) ||
                (content.includes("command") && content.includes(search))
              ) {
                results.push(fullPath);
              }
            }
          }
        }

        scan(baseFolder);

        if (!results.length) {
          return reply(`❌ No file found for "${search}"`);
        }

        let msg = `🔍 *Found ${results.length} file(s):*\n\n`;

        results.forEach((file, i) => {
          msg += `${i + 1}. ${file}\n`;
        });

        reply(msg);

      } catch (e) {
        console.log(e);
        reply("❌ Error while searching file.");
      }
    },
  },
];