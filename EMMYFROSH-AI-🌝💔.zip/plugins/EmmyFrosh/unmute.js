// plugins/EmmyFrosh/unmute.js

module.exports = {
  command: ['unmute'],
  alias: ['allow', 'unsilence'],
  category: 'group',
  description: 'Unmute a user in the group (admin only)',
  group: true,
  admin: true,
  async execute(m, { ednut, isGroup, isAdmins, isBotAdmins, prefix, command, text, reply, args }) {
    
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    if (!global.db.groups[m.chat].mutedUsers) global.db.groups[m.chat].mutedUsers = {};
    
    const mutedUsers = global.db.groups[m.chat].mutedUsers;
    
    // Get target user
    let target = null;
    let targetName = '';
    
    // Check if replying to a message
    if (m.quoted) {
      target = m.quoted.sender;
      targetName = m.quoted.pushName || target.split('@')[0];
    }
    
    // Check for mentions
    if (!target && m.mentionedJid && m.mentionedJid.length > 0) {
      target = m.mentionedJid[0];
      targetName = target.split('@')[0];
    }
    
    // Check for number in args
    if (!target && args.length > 0) {
      const possibleNumber = args[0].replace(/[^0-9]/g, '');
      if (possibleNumber.length >= 10) {
        target = possibleNumber + '@s.whatsapp.net';
        targetName = possibleNumber;
      }
    }
    
    if (!target) {
      await reply(`❌ Please mention the user you want to unmute!\n\nExample: ${prefix + command} @user`);
      return;
    }
    
    // Check if user is muted
    if (!mutedUsers[target]) {
      await reply(`❌ @${target.split('@')[0]} is not muted!`, { mentions: [target] });
      return;
    }
    
    // Unmute the user
    delete mutedUsers[target];
    global.db.groups[m.chat].mutedUsers = mutedUsers;
    
    const unmuteMessage = `🔊 *USER UNMUTED* 🔊\n\n` +
      `*User:* @${target.split('@')[0]}\n` +
      `*Unmuted by:* @${m.sender.split('@')[0]}\n\n` +
      `_User can now send messages again._`;
    
    await ednut.sendMessage(m.chat, {
      text: unmuteMessage,
      contextInfo: { mentionedJid: [target, m.sender] }
    }, { quoted: m });
  }
};