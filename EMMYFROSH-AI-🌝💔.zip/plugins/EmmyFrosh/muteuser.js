// plugins/EmmyFrosh/mute.js

module.exports = {
  command: ['mute', 'muteuser'],
  alias: ['shutup', 'silence'],
  category: 'group',
  description: 'Mute a user in the group (admin only)',
  group: true,
  admin: true,
  async execute(m, { ednut, isGroup, isAdmins, isBotAdmins, prefix, command, text, reply, args, mentionByReply }) {
    
    // Initialize muted users object if it doesn't exist
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    if (!global.db.groups[m.chat].mutedUsers) global.db.groups[m.chat].mutedUsers = {};

    const mutedUsers = global.db.groups[m.chat].mutedUsers;
    
    // Get target user (from mention, reply, or text)
    let target = null;
    let targetName = '';
    let duration = null;
    let reason = 'No reason provided';
    
    // Check if replying to a message
    if (m.quoted) {
      target = m.quoted.sender;
      targetName = m.quoted.pushName || target.split('@')[0];
    }
    
    // Check for mentions
    if (!target && m.mentionedJid && m.mentionedJid.length > 0) {
      target = m.mentionedJid[0];
      targetName = target.split('@')[0];
    }
    
    // Check for number in args
    if (!target && args.length > 0) {
      const possibleNumber = args[0].replace(/[^0-9]/g, '');
      if (possibleNumber.length >= 10) {
        target = possibleNumber + '@s.whatsapp.net';
        targetName = possibleNumber;
      }
    }
    
    // If still no target, show usage
    if (!target) {
      const mutedList = Object.keys(mutedUsers);
      let statusText = `📋 *MUTE USER SYSTEM*\n\n`;
      statusText += `*Commands:*\n`;
      statusText += `▢ ${prefix + command} @user - Mute a user\n`;
      statusText += `▢ ${prefix + command} @user 1h - Mute for 1 hour\n`;
      statusText += `▢ ${prefix + command} @user 1d - Mute for 1 day\n`;
      statusText += `▢ ${prefix + command} @user 1w - Mute for 1 week\n`;
      statusText += `▢ ${prefix + command} @user reason - Mute with reason\n`;
      statusText += `▢ ${prefix + command} @user 1h spamming - Mute with duration and reason\n`;
      statusText += `▢ ${prefix + command} list - List muted users\n`;
      statusText += `▢ ${prefix + command} remove @user - Unmute user\n`;
      statusText += `▢ ${prefix + command} clear - Clear all muted users\n\n`;
      
      if (mutedList.length > 0) {
        statusText += `*Currently Muted Users:*\n`;
        for (const userId of mutedList) {
          const muteInfo = mutedUsers[userId];
          const remaining = muteInfo.expires ? formatRemainingTime(muteInfo.expires) : 'Permanent';
          statusText += `▢ @${userId.split('@')[0]} - ${remaining} - ${muteInfo.reason || 'No reason'}\n`;
        }
      } else {
        statusText += `*No muted users in this group.*\n`;
      }
      
      await reply(statusText);
      return;
    }
    
    // Check if trying to mute bot or admin
    if (target === ednut.user.id) {
      await reply(`❌ I cannot mute myself!`);
      return;
    }
    
    // Check if target is admin
    const groupMetadata = await ednut.groupMetadata(m.chat);
    const groupAdmins = groupMetadata.participants.filter(p => p.admin).map(p => p.id);
    if (groupAdmins.includes(target)) {
      await reply(`❌ Cannot mute a group admin!`);
      return;
    }
    
    // Parse duration from args
    let durationText = '';
    let muteReason = '';
    
    for (let i = 0; i < args.length; i++) {
      const arg = args[i].toLowerCase();
      if (arg.match(/^\d+[smhdw]$/)) {
        durationText = arg;
      } else if (!arg.startsWith('@') && !arg.match(/^\d+$/)) {
        muteReason += (muteReason ? ' ' : '') + args[i];
      }
    }
    
    // Parse duration
    if (durationText) {
      const value = parseInt(durationText);
      const unit = durationText.slice(-1);
      switch (unit) {
        case 's': duration = value * 1000; break;
        case 'm': duration = value * 60 * 1000; break;
        case 'h': duration = value * 60 * 60 * 1000; break;
        case 'd': duration = value * 24 * 60 * 60 * 1000; break;
        case 'w': duration = value * 7 * 24 * 60 * 60 * 1000; break;
        default: duration = null;
      }
    }
    
    reason = muteReason || 'No reason provided';
    const expires = duration ? Date.now() + duration : null;
    
    // Check if user is already muted
    if (mutedUsers[target]) {
      await reply(`⚠️ *User is already muted!*\n\nUse ${prefix + command} remove @${target.split('@')[0]} to unmute.`);
      return;
    }
    
    // Mute the user
    mutedUsers[target] = {
      mutedBy: m.sender,
      mutedAt: Date.now(),
      expires: expires,
      reason: reason,
      name: targetName
    };
    
    // Save to database
    global.db.groups[m.chat].mutedUsers = mutedUsers;
    
    const durationDisplay = duration ? formatDuration(duration) : 'Permanently';
    const muteMessage = `🔇 *USER MUTED* 🔇\n\n` +
      `*User:* @${target.split('@')[0]}\n` +
      `*Duration:* ${durationDisplay}\n` +
      `*Reason:* ${reason}\n` +
      `*Muted by:* @${m.sender.split('@')[0]}\n\n` +
      `_This user's messages will be automatically deleted._`;
    
    await ednut.sendMessage(m.chat, {
      text: muteMessage,
      contextInfo: { mentionedJid: [target, m.sender] }
    }, { quoted: m });
    
    // Set timeout to auto-unmute if duration specified
    if (duration) {
      setTimeout(async () => {
        if (global.db.groups[m.chat]?.mutedUsers?.[target]) {
          delete global.db.groups[m.chat].mutedUsers[target];
          await ednut.sendMessage(m.chat, {
            text: `🔊 *USER UNMUTED* 🔊\n\n@${target.split('@')[0]} has been automatically unmuted after the mute period expired.`,
            contextInfo: { mentionedJid: [target] }
          });
        }
      }, duration);
    }
  }
};

// Helper function to format duration
function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  const weeks = Math.floor(days / 7);
  
  if (weeks > 0) return `${weeks} week${weeks > 1 ? 's' : ''}`;
  if (days > 0) return `${days} day${days > 1 ? 's' : ''}`;
  if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''}`;
  if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''}`;
  return `${seconds} second${seconds > 1 ? 's' : ''}`;
}

function formatRemainingTime(expires) {
  const remaining = expires - Date.now();
  if (remaining <= 0) return 'Expired';
  return formatDuration(remaining);
}