// plugins/EmmyFrosh/mutelist.js

module.exports = {
  command: ['mutelist', 'mutedlist'],
  alias: ['silencedlist', 'mutedusers'],
  category: 'group',
  description: 'List all muted users in the group',
  group: true,
  async execute(m, { ednut, isGroup, isAdmins, isBotAdmins, prefix, command, text, reply }) {
    
    if (!global.db.groups) global.db.groups = {};
    if (!global.db.groups[m.chat]) global.db.groups[m.chat] = {};
    if (!global.db.groups[m.chat].mutedUsers) global.db.groups[m.chat].mutedUsers = {};
    
    const mutedUsers = global.db.groups[m.chat].mutedUsers;
    const mutedList = Object.keys(mutedUsers);
    
    if (mutedList.length === 0) {
      await reply(`📋 *MUTED USERS LIST*\n\nNo users are currently muted in this group.`);
      return;
    }
    
    let message = `📋 *MUTED USERS LIST*\n\n`;
    let index = 1;
    
    for (const userId of mutedList) {
      const muteInfo = mutedUsers[userId];
      const remaining = muteInfo.expires ? formatRemainingTime(muteInfo.expires) : 'Permanent';
      message += `${index}. @${userId.split('@')[0]}\n`;
      message += `   └ *Remaining:* ${remaining}\n`;
      message += `   └ *Reason:* ${muteInfo.reason || 'No reason'}\n`;
      message += `   └ *Muted by:* @${muteInfo.mutedBy?.split('@')[0] || 'Unknown'}\n\n`;
      index++;
    }
    
    message += `\n_To unmute: ${prefix}unmute @user_`;
    
    const mentions = mutedList.concat(Object.values(mutedUsers).map(v => v.mutedBy).filter(Boolean));
    
    await ednut.sendMessage(m.chat, {
      text: message,
      contextInfo: { mentionedJid: mentions }
    }, { quoted: m });
  }
};

function formatRemainingTime(expires) {
  const remaining = expires - Date.now();
  if (remaining <= 0) return 'Expired';
  
  const seconds = Math.floor(remaining / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  const weeks = Math.floor(days / 7);
  
  if (weeks > 0) return `${weeks} week${weeks > 1 ? 's' : ''}`;
  if (days > 0) return `${days} day${days > 1 ? 's' : ''}`;
  if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''}`;
  if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''}`;
  return `${seconds} second${seconds > 1 ? 's' : ''}`;
}