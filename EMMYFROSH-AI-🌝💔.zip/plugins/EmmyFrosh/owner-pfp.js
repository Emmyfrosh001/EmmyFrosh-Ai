const fs = require("fs");
const { downloadContentFromMessage } = require("@whiskeysockets/baileys");

module.exports = [
  {
    command: ["save"],
    alias: ["sv", "send"],
    description: "Download and forward a quoted message (media + view-once)",
    category: "Info",
    ban: false,
    gcban: false,

    execute: async (m, { ednut, botNumber, isOwner, reply }) => {
      try {
        if (!isOwner) return;

        let quoted = m.msg?.contextInfo?.quotedMessage;
        if (!quoted) return reply("Reply to a message or media to download and save.");

        // VIEW-ONCE SUPPORT
        if (quoted.viewOnceMessageV2) {
          quoted = quoted.viewOnceMessageV2.message;
        } else if (quoted.viewOnceMessage) {
          quoted = quoted.viewOnceMessage.message;
        }

        const type = Object.keys(quoted)[0];

        // TEXT
        if (type === "conversation") {
          await ednut.sendMessage(botNumber, {
            text: quoted.conversation
          }, { quoted: m });

          return reply("✅ Saved successfully");
        }

        if (!quoted[type]) return reply("Unsupported message type.");

        const stream = await downloadContentFromMessage(
          quoted[type],
          type.replace("Message", "")
        );

        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
          buffer = Buffer.concat([buffer, chunk]);
        }

        if (!buffer) return reply("❌ Failed to download media.");

        const caption = quoted[type]?.caption || "";

        let jid = botNumber || m.sender;
        jid = jid.toString().replace(/\D/g, "") + "@s.whatsapp.net";

        if (type === "imageMessage") {
          await ednut.sendMessage(jid, { image: buffer, caption }, { quoted: m });
          return reply("✅ Saved successfully");
        }

        if (type === "videoMessage") {
          await ednut.sendMessage(jid, { video: buffer, caption }, { quoted: m });
          return reply("✅ Saved successfully");
        }

        if (type === "audioMessage") {
          await ednut.sendMessage(jid, { audio: buffer, mimetype: "audio/mpeg" }, { quoted: m });
          return reply("✅ Saved successfully");
        }

        if (type === "stickerMessage") {
          await ednut.sendMessage(jid, { sticker: buffer }, { quoted: m });
          return reply("✅ Saved successfully");
        }

        if (type === "documentMessage") {
          await ednut.sendMessage(jid, {
            document: buffer,
            fileName: quoted[type]?.fileName || "file"
          }, { quoted: m });

          return reply("✅ Saved successfully");
        }

        return reply("Unsupported message type.");

      } catch (err) {
        console.error(err);
        reply("❌ Error saving message.");
      }
    }
  },

  {
    command: ["setpp"],
    description: "Set bot profile picture (reply to image)",
    category: "Owner",
    owner: true,

    execute: async (m, { ednut, reply, mime, quoted, prefix, command }) => {
      try {
        if (!quoted) return reply("Reply to an image.");
        if (!/image/.test(mime)) return reply(`Send image with ${prefix + command}`);
        if (/webp/.test(mime)) return reply("Sticker not allowed.");

        const media = await ednut.downloadAndSaveMediaMessage(quoted);
        await ednut.updateProfilePicture(ednut.user.id, { url: media });

        fs.unlinkSync(media);

        return reply("✅ Profile picture set successfully");

      } catch (err) {
        console.error(err);
        reply("❌ Failed to update profile picture.");
      }
    }
  },

  {
    command: ["delpp"],
    description: "Remove bot profile picture",
    category: "Owner",
    owner: true,

    execute: async (m, { ednut, reply }) => {
      try {
        await ednut.removeProfilePicture(ednut.user.id);

        return reply("🗑️ Profile picture deleted successfully");

      } catch (err) {
        console.error(err);
        reply("❌ Failed to remove profile picture.");
      }
    }
  }
];