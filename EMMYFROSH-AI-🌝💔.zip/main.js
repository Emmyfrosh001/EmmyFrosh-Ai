const express = require("express");

if (process.send) {
  process.on("message", (msg) => {
    if (msg && msg.type === "get_memory") {
      const memory = process.memoryUsage();
      process.send({ type: "memory_report", rss: memory.rss });
    }
  });
}

const app = express();
const port = process.env.PORT || 3000;

app.get("/", (_, res) => res.send("Bot is running!"));
app.listen(port);


process.once("uncaughtException", function (err) {
  const e = String(err || "");
  const ignoreErrors = [
    "conflict",
    "Socket connection timeout",
    "not-authorized",
    "already-exists",
    "rate-overlimit",
    "Connection Closed",
    "Timed Out",
    "Value not found",
    "Closing open session in favor of incoming prekey bundle",
    "Closing stale open session for new outgoing prekey bundle",
    "Closing session",
    "bad mac",
    "bad session",
    "Unexpected handshake error",
    "Error: read ECONNRESET"
  ];
  if (ignoreErrors.some((i) => e.toLowerCase().includes(i.toLowerCase()))) return;
  log("ERROR", `[Uncaught Exception] ${err?.stack || e}`);
});

process.once("unhandledRejection", (reason) => {
  if (!String(reason).toLowerCase().includes("conflict")) {
    log("ERROR", `[Unhandled Rejection] ${reason}`);
  }
});

const originalLog = console.log;
const originalError = console.error;
const originalDebug = console.debug;
const originalStdout = process.stdout.write;
const originalStderr = process.stderr.write;

function isNoisy(message) {
  return (
    typeof message === "string" &&
    (message.includes("Bad MAC") ||
      message.includes("Removing old closed session") ||
      message.includes("Closing open session") ||
      message.includes("Closing stale open session") ||
      message.includes("Closing session") ||
      message.includes("Decrypted message with closed session.") ||
      message.includes("Failed to decrypt message with any known session") ||
      message.includes("MessageCounterError: Key used already or never filled") ||
      message.includes("SessionCipher.doDecryptWhisperMessage") ||
      message.includes("SessionCipher.decryptWithSessions"))
  );
}

console.log = (...args) => {
  if (isNoisy(args[0])) return;
  originalLog.apply(console, args);
};

console.error = (...args) => {
  if (isNoisy(args[0])) return;
  originalError.apply(console, args);
};

console.debug = (...args) => {
  if (isNoisy(args[0])) return;
  originalDebug.apply(console, args);
};

process.stdout.write = (chunk, encoding, callback) => {
  if (isNoisy(chunk)) return true;
  return originalStdout.call(process.stdout, chunk, encoding, callback);
};

process.stderr.write = (chunk, encoding, callback) => {
  if (isNoisy(chunk)) return true;
  return originalStderr.call(process.stderr, chunk, encoding, callback);
}; 

require("./lib/update")();
require("./config.js");
const chalk = require("chalk");

global.log = function (level, msg) {
  const now = new Date();
  const dd = now.getDate().toString().padStart(2, "0");
  const mm = (now.getMonth() + 1).toString().padStart(2, "0");
  const yy = now.getFullYear().toString().slice(-2);
  const timestamp = now.toLocaleTimeString("en-GB") + ` ${dd}-${mm}-${yy}`;

  const tag = String(level || "INFO").toUpperCase();
  const label =
    tag === "INFO"
      ? chalk.blue(tag)
      : tag === "WARN"
      ? chalk.yellow(tag)
      : tag === "ERROR"
      ? chalk.red(tag)
      : tag === "FATAL"
      ? chalk.red.bold(tag)
      : tag;

  console.log(`${label} [${timestamp}]:`, chalk.blue(msg));
};

require("events").EventEmitter.defaultMaxListeners = 600;

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  jidDecode,
  downloadContentFromMessage,
  delay,
  Browsers,
  makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys");

const { fetchLatestBaileysVersion } = require("@whiskeysockets/baileys");
const { makeInMemoryStore } = require("./store");
const pino = require("pino");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const { Boom } = require("@hapi/boom");
const yargs = require("yargs/yargs");
const NodeCache = require("node-cache");
const moment = require("moment-timezone");
const FileType = require("file-type");
const axios = require("axios");
const _ = require("lodash");
const PhoneNumber = require("awesome-phonenumber");
const AdmZip = require("adm-zip");

const DataBase = require("./lib/database");
const { delArrSave } = require("./lib/arrfunction.js");
require('dotenv').config();

const {
  smsg,
  imageToWebp,
  videoToWebp,
  writeExif,
  writeExifImg,
  writeExifVid,
  toAudio,
  toPTT,
  toVideo,
  getBuffer,
  getSizeMedia
} = require("./all/myfunc");

const { getTime, tanggal, toRupiah, telegraPh, pinterest, ucapan, generateProfilePicture } = require("./all/function.js");

const { color } = require("./all/color");

const store = makeInMemoryStore({
  logger: pino().child({
    level: "silent",
    stream: "store"
  })
});

global.opts = new Object(yargs(process.argv.slice(2)).exitProcess(false).parse());

const groupCache = new NodeCache({
  stdTTL: 3600
});

const pkg = require("./package.json");

const deleteFolderRecursive = function (pathesi) {
  if (fs.existsSync(pathesi)) {
    fs.readdirSync(pathesi).forEach((file) => {
      const curPath = path.join(pathesi, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        deleteFolderRecursive(curPath);
      } else {
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(pathesi);
  }
};

const question = (text) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  return new Promise((resolve) => rl.question(text, resolve));
};

global.allPlugins = [];

async function pluginsLoader(directory) {
  let plugins = [];
  const files = fs.readdirSync(directory);

  for (const file of files) {
    const filePath = path.join(directory, file);

    if (filePath.endsWith(".js")) {
      try {
        const resolvedPath = require.resolve(filePath);
        if (require.cache[resolvedPath]) {
          delete require.cache[resolvedPath];
        }

        const plugin = require(filePath);
        if (Array.isArray(plugin)) {
          plugins.push(...plugin);
        } else {
          plugins.push(plugin);
        }
      } catch (error) {
        log("ERROR", `Error loading plugin from disk ${filePath}: ${error?.message || error}`);
      }
    }
  }
  return plugins;
}

function loadPluginsFromDb() {
  let plugins = [];
  if (global.db?.plugins && typeof global.db.plugins === "object") {
    for (const [filename, code] of Object.entries(global.db.plugins)) {
      try {
        const plugin = eval(`(function(){${code}\nreturn module.exports;})();`);
        if (Array.isArray(plugin)) {
          plugins.push(...plugin);
        } else {
          plugins.push(plugin);
        }
      } catch (err) {
        log("ERROR", `Failed to load plugin from DB: ${filename} — ${err?.message || err}`);
      }
    }
  }
  return plugins;
}

async function loadAllPlugins() {
  if (global.allPlugins.length > 0) return;

  log("INFO", "Loading all plugins...");

  try {
    const pluginsFromDisk = await pluginsLoader(path.resolve(__dirname, "./plugins/EmmyFrosh"));
    const pluginsFromDb = loadPluginsFromDb();
    global.allPlugins = [...pluginsFromDisk, ...pluginsFromDb];
    log("INFO", `✅ Successfully loaded ${global.allPlugins.length} plugins.`);
  } catch (error) {
    log("FATAL", `Failed to initialize plugins: ${error.message}`);
  }
}

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function cleanDir(dirPath) {
  try {
    if (fs.existsSync(dirPath)) fs.rmSync(dirPath, { recursive: true, force: true });
  } catch (e) {
    log("WARN", `Failed cleaning dir ${dirPath}: ${e?.message || e}`);
  }
}

const restoreSessionFromServerZip = async (sessionId, destDir) => {
  const expectedPrefix = "Emmy-Frosh-AI:~";
  const pairSite = global.scan;
  const API_PASSWORD = process.env.API_PASSWORD || "passcode2026";

  if (!sessionId || !sessionId.startsWith(expectedPrefix)) {
    throw new Error(`Invalid format. Must start with "${expectedPrefix}"`);
  }

  const backupId = sessionId.slice(expectedPrefix.length).trim();

  if (!/^[a-f0-9]{32}$/i.test(backupId)) {
    throw new Error("Invalid Session ID. Backup token must be 32 hex characters.");
  }

  const url = `${pairSite}/code/restore?id=${encodeURIComponent(backupId)}`;

  let resp;
  try {
    resp = await axios.get(url, {
      responseType: "arraybuffer",
      headers: {
        Authorization: `Bearer ${API_PASSWORD}`
      },
      timeout: 45000,
      maxContentLength: Infinity,
      maxBodyLength: Infinity
    });
  } catch (e) {
    const status = e?.response?.status;

    if (status === 401) {
      throw new Error("Unauthorized restore request. Wrong API password.");
    }

    if (status === 404) {
      throw new Error("Session ID expired. Pair or scan again.");
    }

    throw new Error(`Restore download failed: ${e?.message || e}`);
  }

  // 🔥 ensure it's actually a zip
  if (!resp.headers["content-type"]?.includes("zip")) {
    const text = Buffer.from(resp.data).toString();
    throw new Error(`Invalid restore response: ${text}`);
  }

  const zip = new AdmZip(Buffer.from(resp.data));

  try {
    if (fs.existsSync(destDir)) {
      fs.rmSync(destDir, { recursive: true, force: true });
    }
  } catch {}

  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }

  zip.extractAllTo(destDir, true);

  const credsPath = path.join(destDir, "creds.json");

  if (!fs.existsSync(credsPath)) {
    throw new Error("Restore failed: creds.json not found after unzip");
  }

  return credsPath;
};

async function startBotz() {

    const expectedPrefix = "Emmy-Frosh-AI:~";

let sessionId =
  process.env.SESSION_ID ||
  global.session ||
  null;

const fs = require("fs");
const path = "./session/creds.json";

// ✅ 1. Check if session already exists locally
let hasValidLocalSession = false;

if (fs.existsSync(path)) {
  try {
    const creds = JSON.parse(fs.readFileSync(path));
    if (creds?.registered === true) {
      hasValidLocalSession = true;
      log("INFO", "Checking Session Auth State...");
    }
  } catch (e) {
    console.log("⚠️ Failed to read creds.json");
  }
}

// ✅ 2. If local session exists → skip everything
if (!hasValidLocalSession) {
  
  // ✅ 3. Check config/env session
  if (sessionId) {
    if (!sessionId.startsWith(expectedPrefix)) {
      throw new Error("Invalid session prefix.\n\n");
    }

    await restoreSessionFromServerZip(sessionId, "./session");
    log("INFO", `Session verified successfully`);

  } else {
    // ❌ Ask user ONLY if nothing exists
    console.log(
      chalk.bgBlack(
        chalk.rgb(255, 165, 0)(
          `\nEMMY FROSH-AI SETUP\n1. Enter Session ID\n2. Pair with Phone Number\n`
        )
      )
    );

    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    const ask = (q) =>
      new Promise((res) => rl.question(q, (ans) => res(ans.trim())));

    let choice = await ask(
      chalk.bgBlack(
        chalk.rgb(255, 165, 0)(`\nChoose (1 or 2): \n\n`)
      )
    );

    while (!["1", "2"].includes(choice)) {
      console.log(chalk.red("❌ Invalid choice.\n\n"));
      await delay(500);

      choice = await ask(
        chalk.bgBlack(
          chalk.rgb(255, 165, 0)(`\nChoose (1 or 2): \n\n`)
        )
      );
    }

    if (choice === "1") {
      sessionId = await ask(
        chalk.bgBlack(
          chalk.greenBright(
            `\nPaste Session ID\nFormat: Emmy-Frosh-AI:~xxxx\n\nSession ID:\n\n`
          )
        )
      );

      rl.close();

      if (!sessionId.startsWith(expectedPrefix)) {
        throw new Error("Invalid session prefix.\n\n");
      }

      await restoreSessionFromServerZip(sessionId, "./session");

      console.log(chalk.green("✅ Session restored successfully!"));

      // 🔥 SAVE TO CONFIG (PERSIST)
      persistSession(sessionId);
    }

    if (choice === "2") {
      rl.close();
      log("INFO", "Proceeding with phone pairing...");
    }
  }
}

  const { state, saveCreds } = await useMultiFileAuthState("./session");
  const { version, isLatest } = await fetchLatestBaileysVersion();
  const database = new DataBase(process.env.DATABASE_URL);
  const existing = await database.read();

  global.db = {
    reconnect: 0,
    loadedPlugins: false,
    groups: {},
    settings: {},
    database: {},
    sticker: {},
    warns: {},
    setsudo: [],
    disabled: [],
    ban: [],
    gcban: [],
    plugins: {},
    ...existing
  };

  if (global.allPlugins.length === 0) {
    await loadAllPlugins();
  }

  const ednut = makeWASocket({
  auth: state,
  version,
  logger: pino({ level: "silent" }),
  printQRInTerminal: false,
  browser: ["Ubuntu", "Chrome", "20.0.04"],
  connectTimeoutMs: 60000,
  keepAliveIntervalMs: 10000,
  retryRequestDelayMs: 250,
  maxMsgRetryCount: 5,
  defaultQueryTimeoutMs: 60000
});


    // 🔥 ADD THIS BLOCK

if (!state.creds.registered) {
  console.log(
    chalk.bgBlack(
      chalk.rgb(255, 165, 0)(`\nEMMY FROSH-AI PAIRING MODE\n`)
    )
  );

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  const ask = (q) =>
    new Promise((resolve) => rl.question(q, resolve));

  const phoneNumber = await ask(
    chalk.greenBright(
      "\nEnter WhatsApp number (with country code)\nExample: 2348012345678\n\nNumber:\n"
    )
  );

  rl.close();

  const cleanNumber = phoneNumber.replace(/\D/g, "");

  const code = await ednut.requestPairingCode(cleanNumber);

  console.log(
    chalk.black(
      chalk.bgWhite(`\nPAIR CODE: ${code}\n`)
    )
  );

  console.log(
    chalk.cyan("\nWhatsApp → Linked devices → Link a device → Enter code\n")
  );
}

  global.ednut = ednut;
  store.bind(ednut);

  require("./all/connect/messages")(ednut, store);
  require("./all/connect/connection")(ednut, startBotz);
  require("./all/connect/creds")(ednut, store, saveCreds);
  require("./all/connect/call")(ednut);
  require("./all/connect/group")(ednut);
  require("./all/connect/statuslike")(ednut, store);

  setInterval(async () => {
    try {
      await database.write(global.db);
    } catch (e) {
      log("ERROR", `DB Save: ${e.message}`);
    }
  }, 10000);

    setInterval(() => {
  const tmpDir = path.join(__dirname, "./tmp");

  // ✅ ONLY clean tmp folder
  if (fs.existsSync(tmpDir)) {
    const keep = ["session", "store", "arch.jpg", "data.js", "helper.js"];
    const entries = fs.readdirSync(tmpDir);

    for (const entry of entries) {
      if (!keep.includes(entry)) {
        const fullPath = path.join(tmpDir, entry);
        try {
          const stat = fs.statSync(fullPath);
          if (stat.isDirectory()) {
            fs.rmSync(fullPath, { recursive: true, force: true });
          } else {
            fs.unlinkSync(fullPath);
          }
        } catch {}
      }
    }
  }

  if (global.gc) global.gc();
}, 30 * 60 * 1000);

  ednut.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
    } else return jid;
  };

  ednut.getName = (jid, withoutContact = false) => {
    id = ednut.decodeJid(jid);
    withoutContact = ednut.withoutContact || withoutContact;
    let v;
    if (id.endsWith("@g.us"))
      return new Promise(async (resolve) => {
        v = store.contacts[id] || {};
        if (!(v.name || v.subject)) v = (await ednut.groupMetadata(id)) || {};
        resolve(v.name || v.subject || PhoneNumber("+" + id.replace("@s.whatsapp.net", "")).getNumber("international"));
      });
    else {
      v =
        id === "0@s.whatsapp.net"
          ? { id, name: "WhatsApp" }
          : id === ednut.decodeJid(ednut.user.id)
          ? ednut.user
          : store.contacts[id] || {};
      return (withoutContact ? "" : v.name) || v.subject || v.verifiedName || PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber("international");
    }
  };

  ednut.serializeM = (m) => smsg(ednut, m, store);
  ednut.sendText = (jid, text, quoted = "", options = {}) => ednut.sendMessage(jid, { text, ...options }, { quoted });

  ednut.sendContact = async (jid, kon, desk = "Developer Bot", quoted = "", opts = {}) => {
    let list = [];
    for (let i of kon) {
      list.push({
        displayName: botname,
        vcard:
          "BEGIN:VCARD\n" +
          "VERSION:3.0\n" +
          `N:;${botname};;;\n` +
          `FN:${botname}\n` +
          "ORG:null\n" +
          "TITLE:\n" +
          `item1.TEL;waid=${i}:${i}\n` +
          "item1.X-ABLabel:Ponsel\n" +
          `X-WA-BIZ-DESCRIPTION:${desk}\n` +
          `X-WA-BIZ-NAME:${botname}\n` +
          "END:VCARD"
      });
    }
    ednut.sendMessage(jid, { contacts: { displayName: `${list.length} contacts`, contacts: list }, ...opts }, { quoted });
  };

  ednut.downloadMediaMessage = async (message) => {
    let mime = (message.msg || message).mimetype || "";
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0];
    const stream = await downloadContentFromMessage(message, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    global.gc?.();
    return buffer;
  };

  ednut.sendImageAsSticker = async (jid, pathx, quoted, options = {}) => {
    let buff = Buffer.isBuffer(pathx)
      ? pathx
      : /^data:.?\/.?;base64,/i.test(pathx)
      ? Buffer.from(pathx.split`,`[1], "base64")
      : /^https?:\/\//.test(pathx)
      ? await (await getBuffer(pathx))
      : fs.existsSync(pathx)
      ? fs.readFileSync(pathx)
      : Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) buffer = await writeExifImg(buff, options);
    else buffer = await imageToWebp(buff);
    await ednut.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
    buff = null;
    buffer = null;
    global.gc?.();
    return buffer;
  };

  ednut.sendVideoAsSticker = async (jid, pathx, quoted, options = {}) => {
    let buff = Buffer.isBuffer(pathx)
      ? pathx
      : /^data:.?\/.?;base64,/i.test(pathx)
      ? Buffer.from(pathx.split`,`[1], "base64")
      : /^https?:\/\//.test(pathx)
      ? await (await getBuffer(pathx))
      : fs.existsSync(pathx)
      ? fs.readFileSync(pathx)
      : Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) buffer = await writeExifVid(buff, options);
    else buffer = await videoToWebp(buff);
    await ednut.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
    buff = null;
    buffer = null;
    global.gc?.();
    return buffer;
  };

  ednut.reply = (jid, text = "", quoted, options) => {
    return Buffer.isBuffer(text)
      ? ednut.sendFile(jid, text, "file", "", quoted, false, options)
      : ednut.sendMessage(jid, { ...options, text }, { quoted });
  };

  ednut.sendMedia = async (jid, pathx, quoted, options = {}) => {
    let { ext, mime, data } = await ednut.getFile(pathx);
    let messageType = mime.split("/")[0];
    let pase = messageType.replace("application", "document") || messageType;
    const res = await ednut.sendMessage(jid, { [pase]: data, mimetype: mime, ...options }, { quoted });
    data = null;
    global.gc?.();
    return res;
  };

  ednut.getFile = async (PATH, save) => {
    let res;
    let data = Buffer.isBuffer(PATH)
      ? PATH
      : /^data:.*?\/.*?;base64,/i.test(PATH)
      ? Buffer.from(PATH.split(",")[1], "base64")
      : /^https?:\/\//.test(PATH)
      ? await (res = await getBuffer(PATH))
      : fs.existsSync(PATH)
      ? fs.readFileSync(PATH)
      : typeof PATH === "string"
      ? PATH
      : Buffer.alloc(0);

    let type = (await FileType.fromBuffer(data)) || { mime: "application/octet-stream", ext: ".bin" };
    let filename = path.join(__dirname, "./tmp/" + new Date().getTime() + "." + type.ext);
    if (data && save) fs.promises.writeFile(filename, data);
    return { res, filename, size: await getSizeMedia(data), ...type, data };
  };

  ednut.sendFile = async (jid, pathx, filename = "", caption = "", quoted, ptt = false, options = {}) => {
    let type = await ednut.getFile(pathx, true);
    let { res, data: file, filename: pathFile } = type;

    if ((res && res.status !== 200) || file.length <= 65536) {
      try {
        throw { json: JSON.parse(file.toString()) };
      } catch (e) {
        if (e.json) throw e.json;
      }
    }

    let opt = { filename };
    if (quoted) opt.quoted = quoted;
    if (!type) options.asDocument = true;

    let mtype = "",
      mimetype = type.mime,
      convert;

    if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = "sticker";
    else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = "image";
    else if (/video/.test(type.mime)) mtype = "video";
    else if (/audio/.test(type.mime)) {
      convert = await (ptt ? toPTT : toAudio)(file, type.ext);
      file = convert.data;
      pathFile = convert.filename;
      mtype = "audio";
      mimetype = "audio/ogg; codecs=opus";
    } else mtype = "document";

    if (options.asDocument) mtype = "document";

    let message = {
      ...options,
      caption,
      ptt,
      [mtype]: { url: pathFile },
      mimetype
    };

    let m;
    try {
      m = await ednut.sendMessage(jid, message, { ...opt, ...options });
    } catch (e) {
      console.error(e);
      m = null;
    } finally {
      if (!m) m = await ednut.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });

      if (fs.existsSync(pathFile)) {
        try {
          await fs.promises.unlink(pathFile);
        } catch (err) {
          console.error("Failed to delete temp file:", err);
        }
      }

      file = null;
      global.gc?.();
      return m;
    }
  };

  ednut.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
    let quoted = message.m ? message.m : message;
    let mime = (message.m || message).mimetype || "";
    let messageType = message.mtype ? message.mtype.replace(/Message/gi, "") : mime.split("/")[0];
    const stream = await downloadContentFromMessage(quoted, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }

    let type = await FileType.fromBuffer(buffer);
    let trueFileName = attachExtension ? filename + "." + type.ext : filename;
    const dir = "./tmp/";
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    const filePath = `${dir}/${trueFileName}`;
    await fs.writeFileSync(filePath, buffer);

    buffer = null;
    global.gc?.();

    return filePath;
  };

  return ednut;
}

async function startBot() {
  if (typeof global.prefix === "undefined") global.prefix = ".";

  try {
    await loadAllPlugins();

    if (global.ednut?.ev) {
      try {
        global.ednut.ev.removeAllListeners();
      } catch {}
    }

    await startBotz();
    log("INFO", "Bot is starting...");

  } catch (error) {
    log("ERROR", error?.stack || error);
  }
}

startBot();