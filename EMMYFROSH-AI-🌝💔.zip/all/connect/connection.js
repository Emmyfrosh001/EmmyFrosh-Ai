const fs = require("fs");
const pkg = require("../../package.json");
const getLatestGitHubVersion = require("../getversion");
const { DisconnectReason } = require("@whiskeysockets/baileys");

require("events").EventEmitter.defaultMaxListeners = 100;

/* =========================
   GLOBAL SAFETY LOCK
========================= */
global.reconnecting = global.reconnecting || false;

process.on("uncaughtException", (err) => {
  console.error("[FATAL ERROR]", err);
});

process.on("unhandledRejection", (err) => {
  console.error("[UNHANDLED REJECTION]", err);
});

module.exports = function handleConnectionUpdate(ednut, startBotz) {

  let reconnecting = false;

  const onConnectionUpdate = async (update) => {

    const { connection, lastDisconnect } = update;

    const code =
      lastDisconnect?.error?.output?.statusCode ||
      lastDisconnect?.error?.code ||
      lastDisconnect?.error?.data?.statusCode;

    const errorText = String(lastDisconnect?.error || "");

    global.db = global.db || {};
    global.db.reconnect = global.db.reconnect || 0;

    /* =========================
       CONNECTING
    ========================= */
    if (connection === "connecting") {
      log("INFO", "[*] Connecting to WhatsApp...");
    }

    /* =========================
       CONNECTED
    ========================= */
    if (connection === "open") {

      reconnecting = false;
      global.reconnecting = false;

      const userId = ednut.user.id.split(":")[0];

      log("INFO", `[✓] Connected: ${userId}`);

      try {
        const latest = await getLatestGitHubVersion();

        const versionNote =
          latest && latest !== pkg.version
            ? `⚠️ New version: v${latest}`
            : `✅ Up to date`;

        const msg = `
╭─❏ EMMYFROSH-AI Connected 〙
│ ID: ${userId}
│ Version: v${pkg.version}
│ ${versionNote}
│ Status: Active
╰─────────────────────
`;

        await ednut.sendMessage(
          userId + "@s.whatsapp.net",
          { text: msg }
        );

      } catch (e) {
        console.log(e);
      }
    }

    /* =========================
       DISCONNECTED
    ========================= */
    if (connection === "close") {

      log("WARN", `[!] Disconnected: ${code}`);

      /* =========================
         LOGOUT → PAIR AGAIN
      ========================= */
      if (
        code === DisconnectReason.loggedOut ||
        code === 401 ||
        errorText.includes("logged out")
      ) {

        log("ERROR", "[X] SESSION LOGGED OUT - RESETTING...");

        try {
          if (fs.existsSync("./session")) {
            fs.rmSync("./session", {
              recursive: true,
              force: true
            });
          }
        } catch (e) {
          log("ERROR", e.message);
        }

        reconnecting = false;
        global.reconnecting = false;

        return setTimeout(() => {
          startBotz(true); // pairing mode
        }, 4000);
      }

      /* =========================
         ANTI DOUBLE RECONNECT
      ========================= */
      if (reconnecting || global.reconnecting) return;

      reconnecting = true;
      global.reconnecting = true;

      setTimeout(() => {

        reconnecting = false;
        global.reconnecting = false;

        try {
          if (ednut?.ws?.readyState === 1) {
            ednut.ws.close();
          }
        } catch {}

        startBotz(false);

      }, 6000);
    }
  };

  /* =========================
     CLEAN LISTENER (SAFE)
  ========================= */
  ednut.ev.removeAllListeners("connection.update");
  ednut.ev.on("connection.update", onConnectionUpdate);
};