const moment = require("moment-timezone");

const TIMEZONE = "Africa/Lagos";

const readmore =
    String.fromCharCode(8206).repeat(4001);

async function handleStatusDelete(
    m,
    deletedMsg,
    ednut
) {

    const sender =
        deletedMsg.key.participant ||
        deletedMsg.pushName ||
        "Unknown";

    const time =
        moment(
            deletedMsg.messageTimestamp * 1000
        )
        .tz(TIMEZONE)
        .format("HH:mm");

    const date =
        moment(
            deletedMsg.messageTimestamp * 1000
        )
        .tz(TIMEZONE)
        .format("DD/MM/YYYY");

    try {

        const forwarded =
            await ednut.sendMessage(
                ednut.user.id,
                {
                    forward: deletedMsg,
                    contextInfo: {
                        isForwarded: false
                    }
                },
                {
                    quoted: deletedMsg
                }
            );
            
        const botJid =
    ednut.user.id.includes(":")
        ? ednut.user.id.split(":")[0] + "@s.whatsapp.net"
        : ednut.user.id;
        await ednut.sendMessage(
            botJid,
            {
                text:
`✝️ DELETED STATUS
┃ 👤 Author: @${sender.split("@")[0]}
┃ ⏰ Time: ${time}
┃ 📅 Date: ${date}
╰━━━━━━━━━━━━━━━━━━⬣

Deleted status recovered successfully.${readmore}`,
                mentions: [sender]
            },
            {
                quoted: forwarded
            }
        );

    } catch (error) {

        console.error(
            "Status Delete Error:",
            error
        );
    }
}

async function processDelete(
    jid,
    m,
    deletedMsg,
    ednut
) {

    try {

        const messageId =
            deletedMsg.key.id;

        const deletedBy =
            m.sender;

        const sender =
            deletedMsg.key.participant ||
            deletedMsg.key.remoteJid;

        let chatName;

        if (m.isGroup) {

            try {

                const groupInfo =
                    await ednut.groupMetadata(
                        m.chat
                    );

                chatName =
                    groupInfo.subject ||
                    "Group Chat";

            } catch {

                chatName =
                    "Group Chat";
            }

        } else {

            chatName =
                deletedMsg.pushName ||
                m.pushName ||
                "Private Chat";
        }

        const time =
            moment(
                deletedMsg.messageTimestamp * 1000
            )
            .tz(TIMEZONE)
            .format("HH:mm");

        const date =
            moment(
                deletedMsg.messageTimestamp * 1000
            )
            .tz(TIMEZONE)
            .format("DD/MM/YYYY");

        const text =
            deletedMsg.message?.conversation ||
            deletedMsg.message
                ?.extendedTextMessage?.text;

        if (!text) {

            try {

                const forwarded =
                    await ednut.sendMessage(
                        jid,
                        {
                            forward: deletedMsg,
                            contextInfo: {
                                isForwarded: false
                            }
                        },
                        {
                            quoted: deletedMsg
                        }
                    );

                return await ednut.sendMessage(
                    jid,
                    {
                        text:
`✝️ DELETED MEDIA
┃ 💬 Chat: ${chatName}
┃ 👤 Sender: @${sender.split("@")[0]}
┃ 🗑️ Deleted By: @${deletedBy.split("@")[0]}
┃ ⏰ Time: ${time}
┃ 📅 Date: ${date}
╰━━━━━━━━━━━━━━━━━━⬣

Recovered media content attached above.${readmore}`,
                        mentions: [
                            sender,
                            deletedBy
                        ]
                    },
                    {
                        quoted: forwarded
                    }
                );

            } catch (mediaErr) {

                console.error(
                    "Media recovery failed:",
                    mediaErr
                );

                return await ednut.sendMessage(
                    jid,
                    {
                        text:
`❌ MEDIA RECOVERY FAILED
┃ 👤 Sender: @${sender.split("@")[0]}
┃ 🗑️ Deleted By: @${deletedBy.split("@")[0]}
╰━━━━━━━━━━━━━━━━━━⬣

Unable to recover deleted media.`,
                        mentions: [
                            sender,
                            deletedBy
                        ]
                    }
                );
            }

        } else {

            const quotedMessage = {
                key: {
                    remoteJid: jid,
                    fromMe:
                        sender === ednut.user.id,
                    id: messageId,
                    participant: sender
                },
                message: {
                    conversation: text
                }
            };

            return await ednut.sendMessage(
                jid,
                {
                    text:
`✝️ DELETED MESSAGE
┃ 💬 Chat: ${chatName}
┃ 👤 Sender: @${sender.split("@")[0]}
┃ 🗑️ Deleted By: @${deletedBy.split("@")[0]}
┃ ⏰ Time: ${time}
┃ 📅 Date: ${date}
╰━━━━━━━━━━━━━━━━━━⬣

📩 Recovered Message:
${text}${readmore}`,
                    mentions: [
                        sender,
                        deletedBy
                    ]
                },
                {
                    quoted: quotedMessage
                }
            );
        }

    } catch (err) {

        console.error(
            "Error processing deleted message:",
            err
        );
    }
}

async function handlePrivateDelete(
    m,
    deletedMsg,
    ednut
) {

    const botJid =
    ednut.user.id.includes(":")
        ? ednut.user.id.split(":")[0] + "@s.whatsapp.net"
        : ednut.user.id;

return processDelete(
    botJid,
    m,
    deletedMsg,
    ednut
);
}

async function handleChatDelete(
    m,
    deletedMsg,
    ednut
) {

    return processDelete(
        m.chat,
        m,
        deletedMsg,
        ednut
    );
}

module.exports = {
    handleChatDelete,
    handlePrivateDelete,
    handleStatusDelete,
    readmore
};