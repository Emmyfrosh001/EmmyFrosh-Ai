const fs = require("fs");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const dbDir = path.join(process.cwd(), "Database");

if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}

const dbPath = path.join(dbDir, "store.db");

const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error("❌ Database Error:", err);
    } else {
        console.log("[Emmy-Frosh-AI] Connected to Store Database.");
    }
});

db.serialize(() => {

    db.run(`
        CREATE TABLE IF NOT EXISTS messages (
            messageId TEXT PRIMARY KEY,
            chatId TEXT NOT NULL,
            sender TEXT,
            message TEXT NOT NULL,
            timestamp INTEGER,
            isMedia INTEGER DEFAULT 0,
            viewOnce INTEGER DEFAULT 0
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS contacts (
            jid TEXT PRIMARY KEY,
            name TEXT,
            lastSeen INTEGER
        )
    `);
});

function isMediaMessage(msg) {

    if (!msg) return false;

    const type =
        Object.keys(msg || {})[0];

    return [
        "imageMessage",
        "videoMessage",
        "audioMessage",
        "documentMessage",
        "stickerMessage",
        "viewOnceMessage",
        "viewOnceMessageV2",
        "viewOnceMessageV2Extension"
    ].includes(type);
}

function isViewOnceMessage(message) {

    if (!message) return false;

    const type =
        Object.keys(message || {})[0];

    if (!type) return false;

    return message[type]?.viewOnce || false;
}

async function saveStoredMessages(
    chatId,
    messageId,
    messageObj
) {

    return new Promise((resolve, reject) => {

        const isMedia =
            isMediaMessage(messageObj.message);

        const isViewOnce =
            isViewOnceMessage(messageObj.message);

        db.run(
            `
            INSERT OR REPLACE INTO messages (
                messageId,
                chatId,
                sender,
                message,
                timestamp,
                isMedia,
                viewOnce
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            `,
            [
                messageId,
                chatId,
                messageObj.key.participant ||
                messageObj.key.remoteJid,

                JSON.stringify(messageObj),

                messageObj.messageTimestamp ||
                Math.floor(Date.now() / 1000),

                isMedia ? 1 : 0,
                isViewOnce ? 1 : 0
            ],
            (err) => {

                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            }
        );
    });
}

async function loadMessage(messageId) {

    return new Promise((resolve, reject) => {

        db.get(
            `
            SELECT message
            FROM messages
            WHERE messageId = ?
            `,
            [messageId],
            (err, row) => {

                if (err) {
                    reject(err);
                } else {
                    resolve(
                        row
                            ? JSON.parse(row.message)
                            : null
                    );
                }
            }
        );
    });
}

async function loadChatMessages(
    chatId,
    limit = 100
) {

    return new Promise((resolve, reject) => {

        db.all(
            `
            SELECT message
            FROM messages
            WHERE chatId = ?
            ORDER BY timestamp DESC
            LIMIT ?
            `,
            [chatId, limit],
            (err, rows) => {

                if (err) {
                    reject(err);
                } else {
                    resolve(
                        rows.map(row =>
                            JSON.parse(row.message)
                        )
                    );
                }
            }
        );
    });
}

async function saveContact(jid, name) {

    return new Promise((resolve, reject) => {

        db.run(
            `
            INSERT OR REPLACE INTO contacts (
                jid,
                name,
                lastSeen
            )
            VALUES (?, ?, ?)
            `,
            [
                jid,
                name,
                Math.floor(Date.now() / 1000)
            ],
            (err) => {

                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
            }
        );
    });
}

async function cleanupOldMessages(
    maxAgeHours = 24
) {

    const cutoff =
        Math.floor(Date.now() / 1000) -
        (maxAgeHours * 3600);

    return new Promise((resolve, reject) => {

        db.run(
            `
            DELETE FROM messages
            WHERE timestamp < ?
            `,
            [cutoff],
            function (err) {

                if (err) {

                    reject(err);

                } else {

                    console.log(
                        `[Emmy-Frosh-AI] Cleaned ${this.changes} old messages`
                    );

                    resolve();
                }
            }
        );
    });
}

module.exports = {
    saveStoredMessages,
    loadMessage,
    loadChatMessages,
    saveContact,
    cleanupOldMessages
};