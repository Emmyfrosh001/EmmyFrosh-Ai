const { fork } = require("child_process");
const chalk = require("chalk");

// ===============================
// CONFIG
// ===============================
const MAX_MEMORY_MB = 800;
const MEMORY_CHECK_INTERVAL_MS = 15000;
const RESTART_DELAY = 5000;

// ===============================
// VARIABLES
// ===============================
let child = null;
let memoryCheckTimer = null;
let restarting = false;

// ===============================
// START BOT
// ===============================
function start() {

    if (restarting) return;

    restarting = true;

    // Kill old process safely
    if (child) {

        console.log(
            chalk.black(
                chalk.bgYellow(
                    "[SYSTEM] Stopping old bot process..."
                )
            )
        );

        try {
            child.removeAllListeners();
            child.kill("SIGKILL");
        } catch (e) {
            console.log(e);
        }
    }

    // Start bot process
    child = fork("./main.js");

    console.log(
        chalk.black(
            chalk.bgGreen(
                `[SYSTEM] Bot started successfully (PID: ${child.pid})`
            )
        )
    );

    restarting = false;

    // ===============================
    // MEMORY MONITOR (NO RAM LOG DISPLAY)
    // ===============================
    child.on("message", (msg) => {

        if (!msg) return;

        if (msg.type === "memory_report" && msg.rss) {

            const currentRssMB = msg.rss / (1024 * 1024);

            // ONLY CHECK — DO NOT PRINT RAM

            if (currentRssMB > MAX_MEMORY_MB) {

                console.log(
                    chalk.black(
                        chalk.bgRed(
                            `[ALERT] RAM exceeded ${MAX_MEMORY_MB}MB. Restarting bot...`
                        )
                    )
                );

                restartBot();
            }

        } else {

            console.log("child to parent =>", msg);

        }
    });

    // ===============================
    // AUTO RESTART ON CLOSE
    // ===============================
    child.on("close", (code) => {

        console.log(
            chalk.black(
                chalk.bgRed(
                    `[SYSTEM] Bot process closed with code ${code}`
                )
            )
        );

        restartBot();
    });

    // ===============================
    // EXIT EVENT
    // ===============================
    child.on("exit", (code) => {

        console.log(
            chalk.yellow(
                `[SYSTEM] Process exited with code ${code}`
            )
        );
    });

    // ===============================
    // MEMORY CHECK TIMER
    // ===============================
    if (memoryCheckTimer) {
        clearInterval(memoryCheckTimer);
    }

    memoryCheckTimer = setInterval(() => {

        if (!child) return;

        if (child.connected) {

            child.send({
                type: "get_memory"
            });

        }

    }, MEMORY_CHECK_INTERVAL_MS);
}

// ===============================
// SAFE RESTART
// ===============================
function restartBot() {

    if (restarting) return;

    restarting = true;

    console.log(
        chalk.black(
            chalk.bgBlue(
                `[SYSTEM] Restarting bot in ${RESTART_DELAY / 1000}s...`
            )
        )
    );

    if (memoryCheckTimer) {
        clearInterval(memoryCheckTimer);
    }

    setTimeout(() => {

        restarting = false;
        start();

    }, RESTART_DELAY);
}

// ===============================
// START SYSTEM
// ===============================
start();