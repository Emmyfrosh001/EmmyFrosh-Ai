const { handleMediaUpload } = require("../../lib/catbox");

module.exports = {
  command: ['setmenuimage'],
  alias: ['menuimage'],
  owner: true,

  execute: async ({ m, Cypher, reply, args, db, saveDatabase }) => {

    if (!db.settings.menuImages) db.settings.menuImages = [];

    let imageUrl = null;

    const quoted = m.quoted || m.msg?.quoted;
    const mime = quoted?.mimetype || quoted?.msg?.mimetype;

    // 📌 Upload from reply
    if (quoted && mime) {
      try {
        imageUrl = await handleMediaUpload(quoted, Cypher, mime);
      } catch {
        return reply("❌ Failed to upload image.");
      }
    }

    // 📌 URL input
    if (!imageUrl && args.length) {
      const input = args.join(" ").trim();
      if (!/^https?:\/\//i.test(input)) {
        return reply("⚠️ Invalid URL.");
      }
      imageUrl = input;
    }

    if (!imageUrl) {
      return reply("Reply image or provide URL.");
    }

    // ✅ Limit to 5
    if (db.settings.menuImages.length >= 5) {
      db.settings.menuImages.shift(); // remove oldest
    }

    db.settings.menuImages.push(imageUrl);


    reply(`✅ Added menu image (${db.settings.menuImages.length}/5)\n${imageUrl}`);
  }
};