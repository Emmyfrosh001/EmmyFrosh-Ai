module.exports = {
  command: ['setmenustyle'],
  alias: ['menustyle'],
  description: 'Change menu style (1=normal, 2=image, 3=channel)',
  owner: true,

  execute: async (m, { reply, args, db, saveDatabase }) => {
    const style = Number(args[0]);

    if (![1, 2, 3].includes(style)) {
      return reply(
        `❌ Invalid style.\n\n` +
        `1 = Normal\n` +
        `2 = Image\n` +
        `3 = Channel`
      );
    }

    db.settings.menustyle = style;

    reply(`✅ Menu style set to *${style}*`);
  }
};