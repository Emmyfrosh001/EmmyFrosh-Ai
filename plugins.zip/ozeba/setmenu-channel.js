module.exports = {
  command: ['setmenuchannel'],
  owner: true,

  execute: async ({ m, reply, args, db, saveDatabase }) => {

    if (args.length < 2) {
      return reply(
        `Usage:\nsetmenuchannel <channel_url> <name>`
      );
    }

    const url = args[0];
    const name = args.slice(1).join(" ");

    db.settings.menuChannel = { url, name };

  
    reply(`✅ Channel menu set:\n${name}\n${url}`);
  }
};