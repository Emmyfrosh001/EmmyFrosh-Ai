const axios = require("axios");

const BASE_API = "https://media.cypherxbot.space/download";

module.exports = [
  {
    command: ["instagram"],
    alias: ["igdl", "ig", "insta"],
    description: "Download Instagram media",
    category: "Downloader",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, text, reply }) => {
      if (!text) return reply("❎ Please input an Instagram link.");
      if (!text.includes("instagram.com")) return reply("❎ Invalid Instagram link!");

      try {
        const { data } = await axios.get(`${BASE_API}?url=${encodeURIComponent(text)}&type=video`);

        if (!data?.status || !data?.result.download_url) {
          return reply("⚠️ Could not retrieve media.");
        }

        await ednut.sendMessage(
          m.chat,
          {
            video: { url: data.result.download_url },
            caption: `🎬 *${data.tittle || "Instagram Video"}*\n${global.footer}`,
            contextInfo: {
              externalAdReply: {
                title: data.tittle || "Instagram Downloader",
                body: "CypherXBot Media Engine",
                thumbnailUrl: data.thumbnail,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          },
          { quoted: m }
        );

      } catch (err) {
        global.log("ERROR", err);
        reply("❎ Instagram download failed.");
      }
    }
  },

  // ✅ FACEBOOK (NOW USING SAME API)
  {
    command: ["facebook"],
    alias: ["fb", "fbvid", "fbvideo"],
    description: "Download Facebook media",
    category: "Downloader",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, text, reply }) => {
      if (!text) return reply("❎ Provide a Facebook link.");
      if (!/(facebook\.com|fb\.watch)/.test(text)) return reply("❎ Invalid Facebook link!");

      try {
        const { data } = await axios.get(`${BASE_API}?url=${encodeURIComponent(text)}&type=video`);

        if (!data?.status || !data?.result.download_url) {
          return reply("⚠️ Could not fetch Facebook media.");
        }

        await ednut.sendMessage(
          m.chat,
          {
            video: { url: data.result.download_url },
            caption: `🎥 *${data.tittle || "Facebook Video"}*\n${global.footer}`
          },
          { quoted: m }
        );

      } catch (err) {
        global.log("ERROR", err);
        reply("❌ Facebook download failed.");
      }
    }
  },

  // ✅ TIKTOK (NOW USING SAME API)
  {
    command: ["tiktok"],
    alias: ["tt", "ttvid"],
    description: "Download TikTok video",
    category: "Downloader",
    ban: false,
    execute: async (m, { ednut, text, reply }) => {
      if (!text) return reply("❎ Provide a TikTok link.");
      if (!text.includes("tiktok.com")) return reply("❎ Invalid TikTok link!");

      try {
        const { data } = await axios.get(`${BASE_API}?url=${encodeURIComponent(text)}&type=video`);

        if (!data?.status || !data?.result.download_url) {
          return reply("⚠️ Could not fetch TikTok video.");
        }

        await ednut.sendMessage(
          m.chat,
          {
            video: { url: data.result.download_url },
            caption: `🎵 *${data.tittle || "TikTok Video"}*\n${global.footer}`
          },
          { quoted: m }
        );

      } catch (err) {
        global.log("ERROR", err);
        reply("❌ TikTok download failed.");
      }
    }
  },

  // ✅ TIKTOK AUDIO (SAME API WITH TYPE=AUDIO)
  {
    command: ["tiktoksound"],
    alias: ["ttmp3", "tiktokmp3"],
    description: "Download TikTok audio",
    category: "Downloader",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, text, reply }) => {
      if (!text) return reply("❎ Provide a TikTok link.");

      try {
        const { data } = await axios.get(`${BASE_API}?url=${encodeURIComponent(text)}&type=audio`);

        if (!data?.status || !data?.result.download_url) {
          return reply("⚠️ Audio not found.");
        }

        await ednut.sendMessage(
          m.chat,
          {
            audio: { url: data.result.download_url },
            mimetype: "audio/mpeg"
          },
          { quoted: m }
        );

      } catch (err) {
        global.log("ERROR", err);
        reply("❌ TikTok audio download failed.");
      }
    }
  },

  // ✅ SHORTLINK (UNCHANGED)
  {
    command: ["shortlink-dl"],
    description: "Download media from a shortened link",
    category: "Downloader",
    ban: true,
    gcban: true,
    execute: async (m, { ednut, fetch, text, isUrl, reply }) => {
      if (!text) return reply("❎ Provide a URL.");
      if (!isUrl(text)) return reply("❎ Invalid URL.");

      try {
        let api = await fetch(`https://moneyblink.com/st/?api=524de9dbd18357810a9e6b76810ace32d81a7d5f&url=${text}`);
        let res = await api.json();

        await ednut.sendMessage(m.chat, { text: res.url }, { quoted: m });

      } catch (err) {
        global.log("ERROR", err);
        reply("❌ Failed to process shortlink.");
      }
    }
  }
];